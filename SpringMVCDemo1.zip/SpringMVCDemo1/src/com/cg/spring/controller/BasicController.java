package com.cg.spring.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.bean.Person;

@Controller
public class BasicController {

	@RequestMapping("/redirectToJspPage")
	public String displayDate(Model model){
		LocalDate today=LocalDate.now();
		model.addAttribute("date",today);//in show date name vl be the same name of add attribute
		return "ShowDate";
		
	}
	@RequestMapping("/postData")
	public String getUserName(Model model , @RequestParam("userName") String uname)//mapping of url parameter to  this uname
	
	{ model.addAttribute("user",uname);
		return "ShowName";
		}//no showname made for name
		
	@RequestMapping("/redirectToController.obj")
	public String displayRegistrationForm(Model model)
	{
		Person person=new Person();
		model.addAttribute("person",person);
		return "Registration";
	}
	
	@RequestMapping("/postPersonDetails")
	public String getPersonDetails(Model model, @Valid @ModelAttribute("person") Person person,BindingResult result)//binding result contain error messages
	{
		if(result.hasErrors()){
			return "Registration";
		}
		else{
		model.addAttribute("personObj" ,person);
		return "ShowName";
		}
	}
	
}
