package com.cg.spring.bean;



import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



public class Person {

	@NotEmpty(message="first name can not be blank")
	@Size(max=20,min=4,message="first name >=5 and <=20 chars")
	private String firstName;
	@NotEmpty(message="last name can not be blank")
	@Size(max=20,min=4,message="last name >=5 and <=20 chars")
	private String lastName;
	
	@Max(value=50 ,message="age=<50")
	@Min(value=20,message="age>=20")
	private int age;
	private String address;
	private String gender;
	@Pattern(regexp="[0-9]{10}",message="mobile no should contain 10 digits")
	private String mobile;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	
}
