package com.cg.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import com.cg.dto.AssessmentScore;

import com.cg.dto.Trainees;
import com.cg.exception.ModuleException;

import com.cg.service.ModuleService;
import com.cg.service.ModuleServiceImpl;

/**
 * Servlet implementation class ModuleServlet
 */
@WebServlet(urlPatterns={"/add","/ModuleScore"})
public class ModuleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ModuleService mser=new ModuleServiceImpl();
		String target="";
		AssessmentScore aDetails=new AssessmentScore();
		String url=request.getServletPath();
		switch(url){
		case "/add":
			
             
 			
 				try {
 					System.out.println("in servlet");
 					List<Trainees> tlist=mser.getTraineeId();
 					request.setAttribute("tlist", tlist);
 					target="AddAssessmentDetails.jsp";
 				} catch (ModuleException e) {
 					// TODO Auto-generated catch block
 				//	String error=e.getMessage();
 					request.setAttribute("error", e.getMessage());
 					target="Error.jsp";
 				}break;
 				
		
		case "/ModuleScore":
			int grade=0;
			String trainee_id=request.getParameter("trainee_Id");
			long tid=Long.parseLong(trainee_id);
			
			String module_name=request.getParameter("module");
			String mpt_string=request.getParameter("mpt");
			int mpt=Integer.parseInt(mpt_string);
			String mtt_string=request.getParameter("mtt");
			int mtt=Integer.parseInt(mtt_string);
			String assg_string=request.getParameter("assg");
			int assignment=Integer.parseInt(assg_string);
			
			
			aDetails.setTrainee_Id(tid);
			aDetails.setModule_name(module_name);
			aDetails.setMpt(mpt);
			aDetails.setMtt(mtt);
			aDetails.setAss_marks(assignment);
			int total=mpt+mtt+assignment;
			aDetails.setTotal(total);
		   if((total>0)&& (total<=49))
		      grade=0;
		   if((total>49)&& (total<=59))
			   grade=1;
		   if((total>59)&& (total<=69))
			   grade=2;
		   if((total>69)&& (total<=79))
			   grade=3;
		   if((total>79)&& (total<=89))
			   grade=4;
		   if((total>89)&& (total<=100))
			   grade=5;
		   aDetails.setGrade(grade);
			
			try{
				mser.insertAssessmentScore(aDetails);
				request.setAttribute("aDetails", aDetails);
				target="ModuleScore.jsp";
				
			}catch(ModuleException e)
			{
				//String error=e.getMessage();
				request.setAttribute("error", e.getMessage());
				target="Error.jsp";
			}break;
		
		
			
			
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request,response);
	}
}
	
 				
	