package com.cg.dto;

public class Trainees {
	private long traineeid;
    private String traineename;
	
	public Trainees() {
		// TODO Auto-generated constructor stub
		
	}

	public long getTraineeid() {
		return traineeid;
	}

	public void setTraineeid(long traineeid) {
		this.traineeid = traineeid;
	}

	public String getTraineename() {
		return traineename;
	}

	public void setTraineename(String traineename) {
		this.traineename = traineename;
	}

	
}
