package com.cg.dao;

import java.util.List;

import com.cg.dto.AssessmentScore;
import com.cg.dto.Trainees;
import com.cg.exception.ModuleException;




public interface ModuleDao {
public long insertAssessmentScore(AssessmentScore assg) throws ModuleException;
public List<Trainees> getTraineeId() throws ModuleException;

}
