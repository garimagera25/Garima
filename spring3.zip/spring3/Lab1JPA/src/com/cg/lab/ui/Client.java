package com.cg.lab.ui;

import java.util.Scanner;

import com.cg.lab.dto.Author;
import com.cg.lab.service.AuthorService;
import com.cg.lab.service.AuthorServiceImpl;



public class Client {
	
//create sequence auth_id_auto;
	public static void main(String[] args) {
		AuthorService authorService=new AuthorServiceImpl();
		Author a=new Author();
		 System.out.println("select your choice");
		    System.out.println("press 1 to insert");
		    System.out.println("press 2 to remove" );
		    
		    System.out.println("press 3 to update");
		    System.out.println("press 4 to exit");
		Scanner sc= new Scanner(System.in);
		int option=sc.nextInt();
	   
	    switch(option){
	    case 1:
	            a.setAuthorId(1001);
	            a.setFirstName("renuka");
	            a.setLastName("roy");
	            a.setMiddleName("k");
	            a.setPhoneNo(1111111111);
	            authorService.addAuthor(a);
	            System.out.println("inserted");
	            break;
	            
	    case 2: authorService.removeAuthor(1001);
	            System.out.println("removed");
	            break;
	    case 3: System.out.println("enter author id");
    	          Scanner sc1= new Scanner(System.in);
    	           int id=sc1.nextInt();
    	 
    	   
    	   authorService.updateAuthor(id, "gra", "vra", "lra", 1111110000);
           System.out.println("updated");
    case 4: break;
    	default :System.out.println("wrong choice");
    
    }

	    	
	    	   
	            
	    }
	    }

