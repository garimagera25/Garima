package com.cg.lab.service;

import com.cg.lab.dto.Author;

public interface AuthorService {
	public int addAuthor(Author author);
	public void removeAuthor(int aId);
	public Author updateAuthor(int aId,String fname,String mname,String lname,long phn);
}
