package com.cg.lab.service;

import com.cg.lab.dao.AuthorDao;
import com.cg.lab.dao.AuthorDaoImpl;
import com.cg.lab.dto.Author;

public class AuthorServiceImpl implements AuthorService{

	AuthorDao authordao=new AuthorDaoImpl();
	@Override
	public int addAuthor(Author author) {
		// TODO Auto-generated method stub
		return authordao.addAuthor(author);
	}

	@Override
	public void removeAuthor(int aId) {
		// TODO Auto-generated method stub
		 authordao.removeAuthor(aId);
		
	}

	@Override
	public Author updateAuthor(int aId, String fname, String mname,
			String lname, long phn) {
		// TODO Auto-generated method stub
		return authordao.updateAuthor(aId, fname, mname, lname, phn);
	}

}
