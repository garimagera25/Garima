package com.cg.lab.dao;

import javax.persistence.EntityManager;


import com.cg.lab.dto.Author;

public class AuthorDaoImpl implements AuthorDao {
	EntityManager em;
	
    public AuthorDaoImpl(){
    	em=AuthorUtil.getEntityManager();
    }
	@Override
	public int addAuthor(Author author) {
		// TODO Auto-generated method stub
		
		
			em.getTransaction().begin();
			em.persist(author);
	        em.getTransaction().commit();		
			
			return 0;
		}
		
	

	@Override
	public void removeAuthor(int aId) {
		// TODO Auto-generated method stub
em.getTransaction().begin();
		
		Author aj=em.find(Author.class, aId);
		em.persist(aj);
		em.remove(aj);
		em.getTransaction().commit();
		
	}
	@Override
	public Author updateAuthor(int aId, String fname, String mname,
			String lname, long phn) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		Author aupdate=em.find(Author.class, aId);
		aupdate.setFirstName(fname);
		aupdate.setMiddleName(mname);
		aupdate.setLastName(lname);
		aupdate.setPhoneNo(phn);
		em.merge(aupdate);
		em.getTransaction().commit();
		
		
		
		em.close();
		return aupdate;
	}

}
