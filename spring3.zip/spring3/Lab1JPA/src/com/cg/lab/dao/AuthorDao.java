package com.cg.lab.dao;


import com.cg.lab.dto.Author;



public interface AuthorDao {
	public int addAuthor(Author author);
	public void removeAuthor(int aId);
	public Author updateAuthor(int aId,String fname,String mname,String lname,long phn);
}
