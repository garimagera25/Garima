package com.cg.lab.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class AuthorUtil {

	static EntityManagerFactory entityfactory;
	static EntityManager entityManager;
	static 
	{
		entityfactory=Persistence.createEntityManagerFactory("Lab1JPA");
		
	}
	public static EntityManager getEntityManager(){
		//if(entityManager==null && !entityManager.isOpen())
		
			entityManager=entityfactory.createEntityManager();
		
		return entityManager;
	}
}
