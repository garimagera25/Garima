package com.cg.spring.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.entities.Trainee;
import com.cg.spring.service.TraineeService;
 
@Controller
public class TraineeController {
	@Autowired
	TraineeService service;
	
	
	public TraineeService getService() {
		return service;
	}
	public void setService(TraineeService service) {
		this.service = service;
	}
	@RequestMapping("/toLogin")//login using hard code values
	public String check(Model model,@RequestParam("username") String uname,@RequestParam("password") String pwd)
	
	{	System.out.println("in trainee contoller");
		if( uname.equals("capgemini") && pwd.equals("corp123"))
		
			
			return "Home";
		else 
		model.addAttribute("errorMsg","Invalid User");
         return "Error";
	}
	@RequestMapping("/addTrainee")//to populATE THE DOMAIN NAME IN the form
	public String showDomain(Model model)
	{
		System.out.println("in add");
		Trainee trainee=new Trainee();
		//List<Trainee> domainlist=service.getdomainList();
		
		//model.addAttribute("dList",domainlist);
		System.out.println("model control");
		model.addAttribute("trainee",trainee);
		return "Details";
	}
	
/*	@RequestMapping("getLoginPage")
	public String getLoginPage(Model model){
		
		Credentials cred= new Credentials();
		model.addAttribute("creden", cred);
		return "Log";
	}
	*/
	
	@RequestMapping("/insertTrainee")//to insert trainee details in form with validation
	public String addTraineeDetail(Model model,@Valid @ModelAttribute("trainee") Trainee trainee,BindingResult result)
	{
//		System.out.println("controlle check trainee"+trainee);
//		model.addAttribute("trainee",trainee);
//		trainee=service.addTraineeDetails(trainee);
//		model.addAttribute("successMsg","successfully added with"+trainee.getId());
//		return "Success";
		
		if(result.hasErrors()){
			return "Details";
		}
		else{
		
		
		System.out.println("in controller");
		trainee=service.addTraineeDetails(trainee);
		System.out.println("calling");
		model.addAttribute("trainee",trainee);
		model.addAttribute("successMsg","successfully added");
		return "Success";
		}
		
	}
	@RequestMapping("gettraineeListPage")//to print list of all trainees
	public String getBookList(Model model)
	{
		List<Trainee> list=service.getTraineeList();
		model.addAttribute("traineelist",list);
		return "TraineeList";
	}
	@RequestMapping("deleteTrainee")//step 1 for delete
	public String removeTrainee(Model model)
	{
		//service.removeTrainee(tid);
		//List<Trainee> list=service.getTraineeList();
		Trainee trainee=new Trainee();
		
		model.addAttribute("trainee",trainee);
		
		return "Delete";
	}
	@RequestMapping("deleteNow")//step 2 for delete
	public String detailsDelete(Model model,@ModelAttribute("trainee") Trainee trainee)
	
	{
		Trainee thistrainee=service.gettraineeDetails(trainee.getTraineeId());
		if(thistrainee!=null)
		{
		
		System.out.println(trainee.getTraineeId());
		System.out.println("thistrainee"+thistrainee);
	       model.addAttribute("thistrainee",thistrainee);
	      return "Delete";	
		}
		else
		{
			model.addAttribute("errormsg","can't delete");
			return "Error";
		}
	}
	@RequestMapping("deleteThisTrainee")//step 3 for delete
	public String permanentdelete(Model model,@RequestParam("traineeid") int id)
	{
		service.removeTrainee(id);
		model.addAttribute("successMsg","Suceessfully Deleted");
		return "Success";
	}
	@RequestMapping("getOneTrainee")//retrieve part 1
	public String retrieveData(Model model)
	{
     Trainee trainee=new Trainee();
		
		model.addAttribute("trainee",trainee);
		
		return "Retrieve";
	}
	@RequestMapping("retrieveNow")//retrieve part 2
	public String retrieveThisTrainee(Model model,@ModelAttribute("trainee") Trainee trainee)
	{
		Trainee thistrainee=service.gettraineeDetails(trainee.getTraineeId());
		if(thistrainee!=null)
		{	
		model.addAttribute("thistrainee" ,thistrainee);
		return "Retrieve";
		}
		else
			model.addAttribute("errorMsg","Id does not Exist");
    	return "Error";
	}
	@RequestMapping("updateTrainee")//modify part 1
	public String updateTraineefun(Model model)
	{
		Trainee trainee=new Trainee();
		model.addAttribute("trainee",trainee);
		return "Modify";
	}
	@RequestMapping("modifyNow")//modify part 2
	public String detailsUpdate(Model model,@ModelAttribute("trainee") Trainee trainee)
	{
	   Trainee thistrainee=service.gettraineeDetails(trainee.getTraineeId());
//	   model.addAttribute("trainee",trainee);
//		return "Modify";
	    if(thistrainee!=null)
	    { 	
	    	System.out.println("thistrainee"+thistrainee);
		model.addAttribute("thistrainee",thistrainee);
		return "Modify";
	    }
	    else {
	    	System.out.println("thistrainee"+thistrainee);
	    	model.addAttribute("errorMsg","can't update");
	    	return "Error";
	    }
	}
	@RequestMapping("modifyThisTrainee")//modify part 3 final
	public String updateInfo(Model model,@ModelAttribute("trainee") Trainee trainee)
	{
		
		service.updateTrainee(trainee);
		model.addAttribute("successMsg","Updated sucessfully");
		return "Success";
	}
	

}



