package com.cg.spring.service;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.spring.dao.TraineeRepository;
import com.cg.spring.entities.Trainee;
@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeRepository traineerepository;
	
	

	
public TraineeRepository getTraineerepository() {
		return traineerepository;
	}
	public void setTraineerepository(TraineeRepository traineerepository) {
		this.traineerepository = traineerepository;
	}
	//	@Override
//	public List<TraineeRepository> getdomainList() {
//		// TODO Auto-generated method stub
//		return traineerepository.findAll();
//	}
	@Override
	public List<Trainee> getTraineeList() {
		// TODO Auto-generated method stub
		return traineerepository.findAll();
	}
	@Override
	public void removeTrainee(int tid) {
		// TODO Auto-generated method stub
		traineerepository.delete(tid);
	}
	@Override
	public Trainee gettraineeDetails(int tid) {
		// TODO Auto-generated method stub
		return traineerepository.findOne(tid);
	}
	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Trainee addTraineeDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineerepository.saveAndFlush(trainee);
//		System.out.println(trainee);
//		return trainee;
	}
	

}
