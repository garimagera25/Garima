package com.cg.spring.dao;



import com.cg.spring.entities.Trainee;

import org.jboss.logging.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;




@Repository
public interface TraineeRepository  extends
JpaRepository<Trainee, Integer>
{
/*{
   @Modifying
	@Query("update Trainee set traineeName= :name,traineeLoc = :location where traineeId=:id")
	public void updateTrainee( @Param("name") String name ,@Param("location"),@Param("id") int id);
*/	
/*	public Trainee addTraineeDetails(Trainee trainee);
	public List<Trainee> getdomainList() ;
	public List<Trainee> getTraineeList();
	
	
	
	
	
	
	
	
	
	
	
	
	public void removeTrainee(int tid);
	public Trainee gettraineeDetails(int tid);
	public Trainee updateTrainee(Trainee trainee);
*/
}

