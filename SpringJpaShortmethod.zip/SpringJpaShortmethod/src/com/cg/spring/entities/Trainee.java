package com.cg.spring.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;




//@SequenceGenerator(name="tid_id_seq",sequenceName="tid_seq")
@Entity
@Table(name="TraineeDetails")
public class Trainee {

	
//	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="tid_id_seq")
   
	@Id @Column(name="trainee_id")
	private int traineeId;
	@NotEmpty(message="name can not be blank")
	@Size(max=20,min=4,message="first name >=5 and <=20 chars")
	 @Column(name="trainee_name")
	private String traineeName;
	 @Column(name="trainee_domain")
	private String traineeDomain;
	 @Column(name="trainee_loc")
	private String traineeLoc;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLoc() {
		return traineeLoc;
	}
	public void setTraineeLoc(String traineeLoc) {
		this.traineeLoc = traineeLoc;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLoc=" + traineeLoc + "]";
	}

	


	
}
