/*package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.jboss.logging.annotations.Param;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.AssessmentScore;
import com.cg.spring.entities.Trainee;

@Repository
public  class ModuleScoreImpl implements ModuleScoreDao {

	@PersistenceContext
	EntityManager entityManager;
	
	
	public List<Trainee> getTraineeList()
	{
		TypedQuery<Trainee> query=entityManager.createQuery("from Trainee",Trainee.class);
		List<Trainee> tarineeList=query.getResultList();
		return tarineeList;
	}
	
	@Override
	public AssessmentScore insertScore(AssessmentScore ass) {
		// TODO Auto-generated method stub
		entityManager.persist(ass);
		entityManager.flush();
		
		return ass;
	}

	public int check(int id,String name){
	entityManager.getTransaction().begin();
		javax.persistence.Query queryTwo=entityManager.createNamedQuery("getOnce");
	if(queryTwo!=null)
		return 1;
		else return 0;
	}
	}

	*/



	


