package com.cg.spring.dao;

import org.jboss.logging.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.spring.entities.AssessmentScore;
@Repository
public interface ModelRepository extends 
JpaRepository<AssessmentScore, Integer> {
	@Query("select score from AssessmentScore score "
			+ "where score.traineeId =:tid and score.moduleName=:name")	
	public void check(@Param("tid") int id, @Param("name") String mod);
	
	
	
}
