package com.cg.DemoJPA.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.DemoJPA.dto.Employee;

public class MyMain {

	public static void main(String[] args) {
		Employee emp=new Employee();
		emp.setEmpId(10003);
		emp.setEmpName("renuka");
		emp.setEmpDepartment(".net");
		emp.setEmpSalary(9000.23);
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("DemoJPA");//1st step
		EntityManager em=entityManagerFactory.createEntityManager();//2nd step
		
		//insert
	/*	em.getTransaction().begin();//for making a transaction 3rd step
		em.persist(emp);//to persist the data emp by emp 4th step
		em.getTransaction().commit();//5th step i.e,flush like in database we do after creation and insertion
		em.getTransaction().commit();
        em.close();*/
		
		
		
		//Find
	  /*   entityManagerFactory.close();
        em.getTransaction().begin();
	    Employee efind=em.find(Employee.class, 1002);
	    em.close();
	    entityManagerFactory.close();
	    System.out.println("id is"+efind.getEmpId());
	    System.out.println("nameis"+efind.getEmpName());
	    System.out.println("salary is"+efind.getEmpSalary());
	    System.out.println("Dep is"+efind.getEmpDepartment());*/
		
		
	    
		//Remove
		/*	em.getTransaction().begin();
		Employee eremove=em.find(Employee.class, 10001);
		em.remove(eremove);
		em.getTransaction().commit();
	    em.close();
	    entityManagerFactory.close();*/
	    
	    
	    //Update
		
		em.getTransaction().begin();
		Employee eupdate=em.find(Employee.class, 10002);
		eupdate.setEmpName("ren");
		eupdate.setEmpSalary(1000.8);
		eupdate.setEmpDepartment("ppt");
		em.merge(eupdate);
		em.getTransaction().commit();
		em.close();
		entityManagerFactory.close();
	    
	    
	}
}
