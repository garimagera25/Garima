package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="tid_id_seq",sequenceName="tid_seq")
public class Trainee {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="tid_id_seq")
	@Column(name="tid")
	private int id;
	@Column(name="t_name")
	private String name;
	
	@Column(name="t_domain")
	private String domain;
	
	@Column(name="t_location")
	private String loc;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "Trainee [id=" + id + ", name=" + name + ", domain=" + domain
				+ ", loc=" + loc + "]";
	}
	
}
