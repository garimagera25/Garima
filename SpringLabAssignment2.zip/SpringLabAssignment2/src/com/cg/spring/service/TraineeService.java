package com.cg.spring.service;

import com.cg.spring.entities.Trainee;

public interface TraineeService {
	public Trainee addTraineeDetails(Trainee trainee);
}
