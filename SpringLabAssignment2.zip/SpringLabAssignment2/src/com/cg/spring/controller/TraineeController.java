package com.cg.spring.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.entities.Credentials;
import com.cg.spring.entities.Trainee;
import com.cg.spring.service.TraineeService;



@Controller
@RequestMapping("/trainee/")
public class TraineeController {
	
	@Autowired
	TraineeService service;
	
	
/*	@RequestMapping("getLoginPage")
	public String getLoginPage(Model model){
		
		Credentials cred= new Credentials();
		model.addAttribute("creden", cred);
		return "Log";
	}
	
	@RequestMapping("/login")
	public String check(Model model,@ModelAttribute("creden") Credentials cre )
	
	{	
		if( cre.getUsername().equals("admin") && cre.getPassword().equals("admin"))
		{
			model.addAttribute("creden",cre);
			return "Home";
		}
		else 
		{	
		
         return "Log";
		}
	}*/
	@RequestMapping("/addTrainee")
	public String addTraineeDetail(Model model)
	{
		
		Trainee trainee=new Trainee();
		service.addTraineeDetails(trainee);
		
		model.addAttribute("trainee",trainee);
		
		return "Details";
	}
}
