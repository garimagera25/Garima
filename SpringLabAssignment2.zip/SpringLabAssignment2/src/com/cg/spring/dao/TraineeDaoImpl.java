package com.cg.spring.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.Trainee;
@Repository
public class TraineeDaoImpl implements TraineeDao {

	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Trainee addTraineeDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		entityManager.flush();
		
		return trainee;
		
	}

}
