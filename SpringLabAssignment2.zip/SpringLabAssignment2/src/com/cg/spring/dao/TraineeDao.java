package com.cg.spring.dao;

import com.cg.spring.entities.Trainee;



public interface TraineeDao {
	public Trainee addTraineeDetails(Trainee trainee);
}
