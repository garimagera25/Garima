package com.cg.demotwo.dao;

import java.util.List;

import com.cg.demotwo.dto.Project;

public interface IProjectDao {

	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
	public Project updateProject(int projId,String pname,String dname);
	//public void updateProject(Project pro);
	public List<Project> showAllProject();
}
