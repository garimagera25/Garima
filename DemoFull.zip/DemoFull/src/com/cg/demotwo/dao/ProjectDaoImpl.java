package com.cg.demotwo.dao;

import java.util.List;

import javax.persistence.EntityManager;





import com.cg.demotwo.dto.Project;

public class ProjectDaoImpl implements IProjectDao {

	EntityManager em;
	
    public ProjectDaoImpl(){
    	em=ProjectUtil.getEntityManager();
    }
	@Override
	public int addProject(Project proj) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(proj);
        em.getTransaction().commit();		
		
		return proj.getProjectId();
	}

	@Override
	public void removeProject(int projId) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		
		Project pj=em.find(Project.class, projId);
		em.persist(pj);
		em.remove(pj);
		em.getTransaction().commit();
		
	   
	    
	   	}

	@Override
	public Project findProject(int projId) {
		// TODO Auto-generated method stub
        em.getTransaction().begin();
		Project efind=em.find(Project.class, projId);
		System.out.println("id is"+efind.getProjectId());
	    System.out.println("nameis"+efind.getProjectName());
	    System.out.println("salary is"+efind.getProjectDepartment());
		  em.close();

		return efind;
	}
	@Override
	public Project updateProject(int projId,String pname, String dname) {
		// TODO Auto-generated method stub

		em.getTransaction().begin();
		Project pupdate=em.find(Project.class, projId);
		pupdate.setProjectName(pname);
		pupdate.setProjectDepartment(dname);		
		em.merge(pupdate);
		em.getTransaction().commit();
		
		
		
		em.close();
		return pupdate;
	}
	@Override
	public List<Project> showAllProject() {
		// TODO Auto-generated method stub
		
		return null;
	}


}
