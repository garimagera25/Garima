package co.cg.demo.association.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Vech {

	@Id
	private int vechId;
	private String vehName;
	public int getVechId() {
		return vechId;
	}
	public void setVechId(int vechId) {
		this.vechId = vechId;
	}
	public String getVehName() {
		return vehName;
	}
	public void setVehName(String vehName) {
		this.vehName = vehName;
	}
	@Override
	public String toString() {
		return "Vehicle [vechId=" + vechId + ", vehName=" + vehName + "]";
	}
	
}
