package co.cg.demo.association.ui;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import co.cg.demo.association.dto.User;
import co.cg.demo.association.dto.Vech;

public class MyTest {

	public static void main(String[] args) {
		EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("DemoOnAssociation");
		EntityManager em=emFactory.createEntityManager();
		Vech ve=new Vech();
		ve.setVechId(10);
		ve.setVehName("jeep");
		
		Vech vet=new Vech();
		vet.setVechId(20);
		vet.setVehName("i10");
		
		User u=new User();
		u.setUserId(1);
		u.setUserName("A");
		List<Vech> my=new ArrayList<>();
		my.add(ve);
		my.add(vet);
	    u.setV(my);
		//u.setV((List<Vech>) ve);//injecting vech into user
		
		
		
		em.getTransaction().begin();
		em.persist(ve);
		em.persist(vet);
		em.persist(u);
	
		em.getTransaction().commit();
		em.close();
		emFactory.close();
	}
}
