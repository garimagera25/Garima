package com.cg.webservice.bean;

public class Product {
	
	private int productId;
	private String prodName;
	private double price;
	
	
	public Product(int productId, String prodName, double price) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		this.price = price;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	

}
