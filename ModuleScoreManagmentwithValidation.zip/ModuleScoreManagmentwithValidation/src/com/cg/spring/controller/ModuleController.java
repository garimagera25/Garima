package com.cg.spring.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.entities.AssessmentScore;
import com.cg.spring.entities.Trainee;
import com.cg.spring.service.ModuleScoreService;
@Controller
public class ModuleController {
	@Autowired
	ModuleScoreService mser;
	
	@RequestMapping("/addPage")
	public String showTraineeList(Model model)
	{
		
	AssessmentScore assc=new AssessmentScore();
   System.out.println("in controller");
		//Trainee trainee=new Trainee();
		
		//System.out.println("id"+trainee);
		List<Trainee> list=mser.getTraineeList();
		
		model.addAttribute("traineeList",list);
		model.addAttribute("assc",assc);
		System.out.println("assc"+assc);
		return "AddAssessment";
	}
	@RequestMapping("/insertModuleScore")
	public String insertScore(Model model,@Valid @ModelAttribute("assc") AssessmentScore module,BindingResult result)
	{
		if(result.hasErrors()){
			return "AddAssessment";
		}
		else{
			int sc=mser.check(module.getTraineeId(), module.getModuleName());
			System.out.println("in sc"+sc);
			if(sc!=1)
			{
				
				module=mser.insertScore(module);
			    model.addAttribute("module",module);
		        return "ModuleScore";
			}
			else return "Error";
		}
	   
		
	}
}
