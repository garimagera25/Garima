package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@SequenceGenerator(name="sno_id_seq",sequenceName="snoid_seq")
@NamedQueries({
	
	

	@NamedQuery(name="getOnce",query="SELECT score FROM AssessmentScore score where score.traineeId=:tid AND score.moduleName=:mod")})
   public class AssessmentScore {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="sno_id_seq")
	private int sno;
	
	@Column(name="trainee_Id")
	private int traineeId;
	@Column(name="module_name")
	private String moduleName;
	@Max(value=70 ,message="should be grater than mpt>=0")
	@Min(value=0,message="should be less mpt=<70")
	private int mpt;
	@Max(value=15 ,message="mtt>=0")
	@Min(value=0,message="mtt=<15")
	private int mtt;
	@Column(name="ass_marks")
	@Max(value=15 ,message="assMarks=>0")
	@Min(value=0,message="assMarks<=15")
    private int assMarks; 
    private int total ;
   	private int grade;
   	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getMpt() {
		return mpt;
	}
	public void setMpt(int mpt) {
		this.mpt = mpt;
	}
	public int getMtt() {
		return mtt;
	}
	public void setMtt(int mtt) {
		this.mtt = mtt;
	}
	public int getAssMarks() {
		return assMarks;
	}
	public void setAssMarks(int assMarks) {
		this.assMarks = assMarks;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "AssessmentScore [traineeId=" + traineeId + ", moduleName="
				+ moduleName + ", mpt=" + mpt + ", mtt=" + mtt + ", assMarks="
				+ assMarks + ", total=" + total + ", grade=" + grade + "]";
	}
   	
}
