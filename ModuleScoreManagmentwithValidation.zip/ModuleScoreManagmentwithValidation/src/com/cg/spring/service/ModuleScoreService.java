package com.cg.spring.service;

import java.util.List;





import com.cg.spring.entities.AssessmentScore;
import com.cg.spring.entities.Trainee;

public interface ModuleScoreService {
	public AssessmentScore insertScore(AssessmentScore ass);

	public List<Trainee> getTraineeList();
	public int calculate(AssessmentScore sc);
	public int check(int id,String name);
	
}
