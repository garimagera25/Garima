package com.cg.spring.service;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;





import com.cg.spring.dao.ModuleScoreDao;
import com.cg.spring.entities.AssessmentScore;
import com.cg.spring.entities.Trainee;

@Transactional
@Service
public class ModuleScoreServiceImpl implements ModuleScoreService {

	@Autowired
	ModuleScoreDao mdao;

	@Override
	public AssessmentScore insertScore(AssessmentScore ass) {
		// TODO Auto-generated method stub
	 int g=calculate(ass);
	 ass.setGrade(g);
		return mdao.insertScore(ass);
	}
	@Override
	public List<Trainee> getTraineeList() {
		// TODO Auto-generated method stub
		return mdao.getTraineeList();
	}
	@Override
	public int calculate(AssessmentScore sc) {
		// TODO Auto-generated method stub
		
		int grade=0;
		int total=sc.getMpt()+sc.getMtt()+sc.getAssMarks();
		sc.setTotal(total);
		if((total>0)&& (total<=49))
		      grade=0;
		   if((total>49)&& (total<=59))
			   grade=1;
		   if((total>59)&& (total<=69))
			   grade=2;
		   if((total>69)&& (total<=79))
			   grade=3;
		   if((total>79)&& (total<=89))
			   grade=4;
		   if((total>89)&& (total<=100))
			   grade=5;
		
		return grade;
	}
	
	@Override

	public int check(int id,String mod)
	{
	return mdao.check(id, mod);
	}
}
