package com.cg.spring.dao;

import java.util.List;




import com.cg.spring.entities.AssessmentScore;
import com.cg.spring.entities.Trainee;

public interface ModuleScoreDao 
{

	//extends JpaRepository<AssessmentScore ,Integer>
	public AssessmentScore insertScore(AssessmentScore ass);
	public List<Trainee> getTraineeList();
//	public int check(int id,String name);
	public int check(int id, String mod);
	
	
	
}
