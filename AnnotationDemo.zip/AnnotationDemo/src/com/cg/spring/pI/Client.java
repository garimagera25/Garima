package com.cg.spring.pI;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.bean.Employee;



public class Client {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Employee employee=(Employee) context.getBean("emp");
		employee.setEmpId(1333);
		employee.setEmpName("renuka");
		employee.getDept().setDeptId(21);
		employee.getDept().setDeptName("admin");
		
		System.out.println(employee);
	}
}
