package com.cg.spring.bean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {

private String empName;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
private int empId;
@Autowired
private Department dept;
@Override
public String toString() {
	return "Employee [empName=" + empName + ", empId=" + empId + ", dept="
			+ dept + "]";
}
public Department getDept() {
	return dept;
}
public void setDept(Department dept) {
	this.dept = dept;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}

}
