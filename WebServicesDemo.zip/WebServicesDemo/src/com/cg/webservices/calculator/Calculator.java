package com.cg.webservices.calculator;

import javax.jws.WebService;


@WebService(endpointInterface="com.cg.webservices.calculator.CalculatorServer")
public class Calculator {
	
	public int add(int num1,int num2 )
	{return num1+num2;}
	
	public int subtract(int num1,int num2)
	{return num1-num2;}
	
	public int findMax(int num1,int num2)
	{return num1>num2?num1:num2;}
	

}
