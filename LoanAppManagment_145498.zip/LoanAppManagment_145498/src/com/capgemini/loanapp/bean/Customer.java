package com.capgemini.loanapp.bean;

public class Customer {


private long Cust_id;
private String Cust_name;
private String Address;
private String Email;
private String MobileNo;
public long getCust_id() {
	return Cust_id;
}
public void setCust_id(long cust_id) {
	Cust_id = cust_id;
}
public String getCust_name() {
	return Cust_name;
}
public void setCust_name(String cust_name) {
	Cust_name = cust_name;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getMobileNo() {
	return MobileNo;
}
public void setMobileNo(String mobno) {
	MobileNo = mobno;
}
}