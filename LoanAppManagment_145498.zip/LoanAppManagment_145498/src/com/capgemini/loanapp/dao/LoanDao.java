package com.capgemini.loanapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.loanapp.bean.Customer;
import com.capgemini.loanapp.bean.Loan;
import com.capgemini.loanapp.exception.LoanAppException;
import com.cg.loanapp.util.DatabaseConnection;


public class LoanDao implements ILoanDao {


	Connection connection;
	public LoanDao() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	@Override
	public long applyLoan(Loan loan) throws LoanAppException {
		// TODO Auto-generated method stub
		 String insQry=
					"INSERT INTO Loan (Loan_id, Loan_amt,Cust_id ,Duration) values (Loan_seq.nextval,?,?,?) ";
					try {
						PreparedStatement ps = connection.prepareStatement(insQry);
						
						
						ps.setDouble(1,loan.getLoan_amt());
						ps.setLong(2, loan.getCust_id());
						ps.setInt(3, loan.getDuration());
						
						int r= ps.executeUpdate();
						int loanid=0;
						if(r==1){
								Statement st= connection.createStatement();
								ResultSet rs= st.executeQuery("select Loan_seq.currval from dual");
								if(rs.next())
									loanid=rs.getInt(1);
						}
					return loanid;
					} catch (SQLException e) {
						throw new LoanAppException(e.getMessage());
					}
					}
		
	

	@Override
	public long insertCust(Customer cust) throws LoanAppException {
		// TODO Auto-generated method stub
		 String insQry=
					"INSERT INTO customer (Cust_id, Cust_name,Address ,Email,MobileNo) values (Cust_seq.nextval,?,?,?,?) ";
					try {
						PreparedStatement ps = connection.prepareStatement(insQry);
						
						
						ps.setString(1,cust.getCust_name());
						ps.setString(2, cust.getAddress());
						ps.setString(3, cust.getEmail());
						ps.setString(4, cust.getMobileNo());
						
						int r= ps.executeUpdate();
						int custid=0;
						if(r==1){
								Statement st= connection.createStatement();
								ResultSet rs= st.executeQuery("select Cust_seq.currval from dual");
								if(rs.next())
									custid=rs.getInt(1);
						}
					return custid;
					} catch (SQLException e) {
						throw new LoanAppException(e.getMessage());
					}
					

	}
	@Override
	public Customer validateCustomer(Customer customer) throws LoanAppException {
		// TODO Auto-generated method stub
		  
			return customer;
			
		}
		   

		
		
	
	@Override
	public double calculateEMI(double amount, int duration)
			throws LoanAppException {
		// TODO Auto-generated method stub
		double p=amount;
		int n=duration;
		n=n*12;
		double r=9.5;
		double emi=(p*r*(1+r)*n)/((1+r)*(n-1));
		return emi;
	
			
		
	}
		
	}


