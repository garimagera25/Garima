package com.capgemini.loanapp.exception;

public class LoanAppException extends Exception {
	public LoanAppException(String msg) {
		super(msg);
	}
}
