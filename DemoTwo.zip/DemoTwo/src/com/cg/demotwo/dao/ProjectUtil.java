package com.cg.demotwo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ProjectUtil {

	static EntityManagerFactory entityfactory;
	static EntityManager entityManager;
	static 
	{
		entityfactory=Persistence.createEntityManagerFactory("DemoTwo");
		
	}
	public static EntityManager getEntityManager(){
		//if(entityManager==null && !entityManager.isOpen())
		
			entityManager=entityfactory.createEntityManager();
		
		return entityManager;
	}
}
