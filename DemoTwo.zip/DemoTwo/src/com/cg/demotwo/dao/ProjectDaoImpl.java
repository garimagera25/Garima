package com.cg.demotwo.dao;

import java.util.List;

import javax.persistence.EntityManager;





import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.engine.ExecuteUpdateResultCheckStyle;

import com.cg.demotwo.dto.Project;

public class ProjectDaoImpl implements IProjectDao {

	EntityManager em;
	
    public ProjectDaoImpl(){
    	em=ProjectUtil.getEntityManager();
    }
	@Override
	public int addProject(Project proj) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		em.persist(proj);
        em.getTransaction().commit();		
		
    	return proj.getProjectId();
	}

	@Override
	public void removeProject(int projId) {
		// TODO Auto-generated method stub
	/*	em.getTransaction().begin();
		
		Project pj=em.find(Project.class, projId);
		em.persist(pj);
		em.remove(pj);
		em.getTransaction().commit();
	
	*/
		em.getTransaction().begin();
		Query queryRemove=em.createQuery("DELETE FROM Project where projectId=:pid");//projectId is attribute name
	    queryRemove.setParameter("pid",projId);//need to set projid coming from user in pid
	    queryRemove.executeUpdate();//delete quert need execute update
	    em.getTransaction().commit();
	    
	   	}

	@Override
	public Project findProject(int projId) {
		// TODO Auto-generated method stub
        em.getTransaction().begin();
		Project efind=em.find(Project.class, projId);
		System.out.println("id is"+efind.getProjectId());
	    System.out.println("nameis"+efind.getProjectName());
	    System.out.println("salary is"+efind.getProjectDepartment());
		  em.close();

		return efind;
	}
/*	@Override
	public Project updateProject(int projId,String pname, String dname) {
		// TODO Auto-generated method stub

		em.getTransaction().begin();
		Project pupdate=em.find(Project.class, projId);
		pupdate.setProjectName(pname);
		pupdate.setProjectDepartment(dname);		
		em.merge(pupdate);
		em.getTransaction().commit();
		
		
		
		em.close();
		return pupdate;
	}*/
	@Override
	public List<Project> showAllProject() {
		// TODO Auto-generated method stub
		Query queryOne=em.createNamedQuery("getAllData");
	//	TypedQuery<Project> queryOne=em.createQuery("FROM Project", Project.class);
	//	Query queryOne=em.createQuery("FROM Project");//classname in bracket
		List<Project> myList=queryOne.getResultList();
		return myList;
	}
	@Override
	public void updateProject(Project pro) {
		// TODO Auto-generated method stub
		em.getTransaction().begin();
		Query queryupdate=em.createQuery("UPDATE Project SET  projectName=:pname,projectDepartment=:dname where projectId=:pid");
		queryupdate.setParameter("pid", pro.getProjectId());
		queryupdate.setParameter("pname",pro.getProjectName());
		queryupdate.setParameter("dname",pro.getProjectDepartment());
		queryupdate.executeUpdate();
		em.getTransaction().commit();
	
		
		em.getTransaction().commit();
		
	}

}
