package com.cg.demotwo.service;

import java.util.List;

import com.cg.demotwo.dto.Project;

public interface IProjectService {
	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
	//public Project updateProject(int projId,String pname,String dname);
	public void updateProject(Project pro);
	public List<Project> showAllProject();
}
