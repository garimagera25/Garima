package com.cg.demotwo.service;



import java.util.List;

import com.cg.demotwo.dao.IProjectDao;
import com.cg.demotwo.dao.ProjectDaoImpl;
import com.cg.demotwo.dto.Project;

public class ProjectServiceImpl implements IProjectService {

	IProjectDao projectDao=new ProjectDaoImpl();
	@Override
	public int addProject(Project proj) {
		// TODO Auto-generated method stub
		return projectDao.addProject(proj);
	}

	@Override
	public void removeProject(int projId) {
		// TODO Auto-generated method stub
     projectDao.removeProject(projId);
		
	}

	@Override
	public Project findProject(int projId) {
		// TODO Auto-generated method stub
		return projectDao.findProject(projId);
	}

/*	@Override
	public Project updateProject(int projId,String pname,String dname) {
		// TODO Auto-generated method stub
		return projectDao.updateProject(projId,pname,dname);
	}*/

	@Override
	public void updateProject(Project pro) {
		// TODO Auto-generated method stub
		 projectDao.updateProject(pro);
		
	}

	@Override
	public List<Project> showAllProject() {
		// TODO Auto-generated method stub
		return projectDao.showAllProject();
	}

}
