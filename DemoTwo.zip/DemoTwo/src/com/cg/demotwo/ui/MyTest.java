package com.cg.demotwo.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.demotwo.dto.Project;
import com.cg.demotwo.service.IProjectService;
import com.cg.demotwo.service.ProjectServiceImpl;

public class MyTest {

	public static void main(String[] args) {
		IProjectService projectService=new ProjectServiceImpl();
		Project p=new Project();
		 System.out.println("select your choice");
		    System.out.println("press 1 to insert");
		    System.out.println("press 2 to remove" );
		    System.out.println("press 3 to find " );
		    System.out.println("press 4 to update");
		    System.out.println("press 5 to show list of all projects");
		    System.out.println("press 6 to exit");
		Scanner sc= new Scanner(System.in);
		int option=sc.nextInt();
	   
	    switch(option){
	    case 1:
	    	   // p.setProjectId(1002);auto generate
	    	/*System.out.println("enter project ");
	    	Scanner sc2=new Scanner(System.in);*/
	    	System.out.println("enter project ");
	    	Scanner sc2=new Scanner(System.in);
	    	String pname=sc2.next();
	    	System.out.println("enter department");
	    	Scanner sc3=new Scanner(System.in);
	    	String dname=sc3.next();
	    	
	    	
	    	
	    	
	    	    p.setProjectName(pname);
	    	    p.setProjectDepartment(dname);
	    	    projectService.addProject(p);
	    	    System.out.println("inserted");
	    	   //without scanning
	    	  /*  p.setProjectName("ALFA ");
	    	    p.setProjectDepartment("la");
	    	    projectService.addProject(p);
	    	    System.out.println("inserted");*/
	    	    break;
	    case 2:	
	    	  System.out.println("enter project id to be deleted");
	    	  Scanner scr=new Scanner(System.in);
	    	  int rid=scr.nextInt();
	    	  projectService.removeProject(rid);
	    	  
	    	
	    	   /* projectService.removeProject(1002);
	              System.out.println("removed");*/
	            break;
	    case 3: projectService.findProject(1002);
	            System.out.println("found");
	           break;
	    case 4:
	    	/*System.out.println("enter project id");
	    	Scanner sc1= new Scanner(System.in);
	    	int id=sc1.nextInt();
	    	 
	    	   
	    	   projectService.updateProject(1002,"java",".net");
	           System.out.println("updated");*/
	    	System.out.println("enter project id");
	    	Scanner sc1= new Scanner(System.in);
	    	
	    	int uid=sc1.nextInt();
	    	System.out.println("enter project name");
	    	Scanner sc4=new Scanner(System.in);
	    	String pname1=sc4.next();
	    	System.out.println("enter department name");
	    	Scanner sc5=new Scanner(System.in);
	    	String dname1=sc5.next();
	    	p.setProjectId(uid);
	    	p.setProjectName(pname1);
	    	p.setProjectDepartment(dname1);
	    	projectService.updateProject(p);
	    	
	    	break;
	    	
	    case 5://show all 
	    	   List<Project> allData=projectService.showAllProject();
	    	   for(Project project:allData)
	    	   {
	    		   System.out.println("id is"+project.getProjectId());
	    		   System.out.println("name is"+project.getProjectName());
	    		   System.out.println("dep is"+ project.getProjectDepartment());
	    	   }
	    case 6: break;
	    	default :System.out.println("wrong choice");
	    
	    }

	
	
	
	
	}
}
