package com.cg.spring.service;

import java.util.List;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;

public interface IBookingService {
	public List<HotelDetails> getHotelList();
	public BookingDetails insertBook(BookingDetails book);
	public HotelDetails displayhotel(int hotelid);
	public double calculate(int noofrooms,int rate);
	public BookingDetails displaybook(String hotelname);
}
