package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.IBookingDao;
import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;


@Transactional
@Service
public class BookingServiceImpl implements IBookingService {
	@Autowired
	IBookingDao bdao;

	@Override
	public List<HotelDetails> getHotelList() {
		// TODO Auto-generated method stub
		return bdao.getHotelList();
	}

	@Override
	public BookingDetails insertBook(BookingDetails book) {
		// TODO Auto-generated method stub
		return bdao.insertBook(book);
	}

	@Override
	public double calculate(int noofrooms, int rate) {
		// TODO Auto-generated method stub
		int amount=noofrooms*rate;
		return amount;
	}

	@Override
	public HotelDetails displayhotel(int hotelid) {
		// TODO Auto-generated method stub
		return bdao.displayhotel(hotelid);
	}

	@Override
	public BookingDetails displaybook(String hotelname) {
		// TODO Auto-generated method stub
		return bdao.displaybook(hotelname);
	}
}
