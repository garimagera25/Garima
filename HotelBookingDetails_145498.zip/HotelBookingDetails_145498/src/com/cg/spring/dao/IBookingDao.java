package com.cg.spring.dao;

import java.util.List;






import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;



public interface IBookingDao {
	public List<HotelDetails> getHotelList();
	
	public HotelDetails displayhotel(int hotelid);
	public BookingDetails insertBook(BookingDetails book);
	public BookingDetails displaybook(String hotelname);
}
