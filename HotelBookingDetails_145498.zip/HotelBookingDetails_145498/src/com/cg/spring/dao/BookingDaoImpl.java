package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;


@Repository
public class BookingDaoImpl implements IBookingDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<HotelDetails> getHotelList() {
		// TODO Auto-generated method stub

		TypedQuery<HotelDetails> query=entityManager.createQuery("from HotelDetails",HotelDetails.class);
		List<HotelDetails> hotelList=query.getResultList();
		System.out.println("list is"+hotelList);
		return hotelList;
		
		
	}

	@Override
	public BookingDetails insertBook(BookingDetails booking) {
		// TODO Auto-generated method stub
		entityManager.persist(booking);
		entityManager.flush();
		
//		System.out.println("book"+booking);
//		System.out.println("in dao");
		
		return booking;
	
	}
	@Override
	public HotelDetails displayhotel(int id) {
		HotelDetails bean = entityManager.find(HotelDetails.class, id);
		return bean;	
	}

	@Override
	public BookingDetails displaybook(String hotelname) {
		// TODO Auto-generated method stub
		BookingDetails bean = entityManager.find(BookingDetails.class, hotelname);
		return bean;
	}
}
