package com.cg.spring.controller;
import java.util.List;

import javax.validation.Valid;
import javax.xml.ws.BindingType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.entities.BookingDetails;
import com.cg.spring.entities.HotelDetails;
import com.cg.spring.service.IBookingService;

@Controller
public class BookingController {

	@Autowired
	IBookingService bser;
	@RequestMapping("/showList")
	public String showTraineeList(Model model)
	{
		
		HotelDetails hotel=new HotelDetails();
   System.out.println("in controller");
			//Trainee trainee=new Trainee();
		
			//System.out.println("id"+trainee);
			List<HotelDetails> list=bser.getHotelList();
			
			model.addAttribute("hotelList",list);
			model.addAttribute("hotel",hotel);
			System.out.println("list is"+list);
			return "HotelDetails";
		}
	@RequestMapping("/clicktobook")
	public String insertStep(Model model, @ModelAttribute("Hotel") HotelDetails hotel)
	{
		
		    
	           HotelDetails hdetail=bser.displayhotel(hotel.getId());
	           model.addAttribute("hoteldetails",hdetail);
	           BookingDetails bdetails=new BookingDetails();
			   model.addAttribute("Booking",bdetails);
		        return "HotelBooking";
			
		       
		
	  }

	@RequestMapping("/addbooking")
	public String AddBooking(Model model,@Valid @ModelAttribute("Booking") BookingDetails book,BindingResult result)
	{
		if(result.hasErrors()){
			return "HotelBooking";
		}
		else{
		BookingDetails booking=bser.insertBook(book);
		System.out.println("in controller"+booking);
		model.addAttribute("booking",booking);
		
		return "Home";
		}
	}
//	@RequestMapping("/displayBooking")
//	public String showBookingDetails(Model model,@ModelAttribute("bookingDetails") BookingDetails book)
//	{
//		
//		List<HotelDetails> list=bser.getHotelList();
//		
//		book.getNoOfRooms();
//		
//		bser.calculate(noofrooms, rate);
//		
//		return "Home";
//	}
	
}
