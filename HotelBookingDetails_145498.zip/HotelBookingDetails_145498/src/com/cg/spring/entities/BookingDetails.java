package com.cg.spring.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@SequenceGenerator(name="bid_seq",sequenceName="b_id_seq")
@Table(name="bookingdetails")
public class BookingDetails {
	
	//(id number primary key, customername varchar2(30), hotelid number , todate Date, fromdate Date, noofrooms number);
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bid_seq")
	private int id;
	@Column(name="customername")
	@NotEmpty(message=" name can not be blank")
	private String customerName;
	@Column(name="hotelid")
	private int hotelId;
	@Column(name="todate")
	
	private Date toDate;
	@Column(name="fromdate")
	
	private Date fromDate;
	@Column(name="noofrooms")
	@Min(value=1,message="age>=0")
	private int noOfRooms;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public int getNoOfRooms() {
		return noOfRooms;
	}
	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}
	@Override
	public String toString() {
		return "BookingDetails [id=" + id + ", customerName=" + customerName
				+ ", hotelId=" + hotelId + ", toDate=" + toDate + ", fromDate="
				+ fromDate + ", noOfRooms=" + noOfRooms + "]";
	}
	
	
}
