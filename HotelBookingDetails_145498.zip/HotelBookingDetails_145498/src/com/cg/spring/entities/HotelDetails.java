package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="hoteldetails")
public class HotelDetails {
	//id number primary key,  name varchar2(30), rating  varchar2(10), rate number(8,2), availablerooms number);
	@Id
	private int id;
	private String name;
	private String rating;
	private double rate;
	@Column(name="availablerooms")
	private int availableRooms;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public int getAvailableRooms() {
		return availableRooms;
	}
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	@Override
	public String toString() {
		return "HotelDetails [id=" + id + ", name=" + name + ", rating="
				+ rating + ", rate=" + rate + ", availableRooms="
				+ availableRooms + "]";
	}
	
}
