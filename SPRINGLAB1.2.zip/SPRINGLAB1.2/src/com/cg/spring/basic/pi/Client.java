package com.cg.spring.basic.pi;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.cg.spring.basic.bean.Employee;


public class Client {

	public static void main(String[] args) {
	//	Employee emp=new Employee();//reference emp in bean tag in xml
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Employee employee=(Employee) context.getBean("emp");
	
		System.out.println("EMPLOYEE DETAILS");
		
		employee.setEmpId(11);
		employee.setEmpName("renuka");
		employee.setSalary(20000);
		employee.setAge(30);
		
		
		System.out.println(employee);
		
	}
	

}
