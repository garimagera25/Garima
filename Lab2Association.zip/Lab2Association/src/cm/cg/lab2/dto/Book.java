package cm.cg.lab2.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries({
		
		@NamedQuery(name="getAllData",query="FROM Book"),

		@NamedQuery(name="getBetween",query="SELECT title from Book where price Between 500 AND 1000")})

public class Book {
 
	@Id
	private int ISBN;
	private int price;
	private String title;
	
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", price=" + price + ", title=" + title
				+ "]";
	}
	
}
