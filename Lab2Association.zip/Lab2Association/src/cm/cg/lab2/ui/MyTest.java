package cm.cg.lab2.ui;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;





import cm.cg.lab2.dto.Author;
import cm.cg.lab2.dto.Book;

public class MyTest {
public static void main(String[] args) {
	EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("Lab2Association");
	EntityManager em=emFactory.createEntityManager();
		Book b1=new Book();
	b1.setISBN(1);
	b1.setPrice(200);
	b1.setTitle("love");
	
	Book b2=new Book();
	b2.setISBN(2);
	b2.setPrice(300);
	b2.setTitle("freiendship");
	

	Book b3=new Book();
	b3.setISBN(3);
	b3.setPrice(600);
	b3.setTitle("no");
	
	Author a=new Author();
	a.setId(10);
	a.setName("A");
	List<Book> my=new ArrayList<>();
	
	my.add(b1);
	my.add(b2);
	my.add(b3);
    a.setB(my);
    em.getTransaction().begin();
	em.persist(b1);
	em.persist(b2);
	em.persist(b3);
	em.persist(a);

	em.getTransaction().commit();
	
	//to display list of all books
	em.getTransaction().begin();
	Query queryOne=em.createNamedQuery("getAllData");
	List<Book> mylist=queryOne.getResultList();
	System.out.println("all the book"+mylist);
	em.getTransaction().commit();
	
	//to display list of books where price is between 500-1000
	em.getTransaction().begin();
	Query queryTwo=em.createNamedQuery("getBetween");
	//queryTwo.executeUpdate();
	List<Book> mylist1=queryTwo.getResultList();
	
		   System.out.println("title is"+mylist1);
	      
	
	em.getTransaction().commit();
	
	em.close();
	emFactory.close();
	

}
}
