package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.Trainee;
import com.cg.spring.dao.TraineeDao;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao repository;
	@Override
	public Trainee addTraineeDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		return repository.addTraineeDetails(trainee);
	}
	@Override
	public List<Trainee> getdomainList() {
		// TODO Auto-generated method stub
		return repository.getdomainList();
	}
	@Override
	public List<Trainee> getTraineeList() {
		// TODO Auto-generated method stub
		return repository.getTraineeList();
	}
	@Override
	public void removeTrainee(int tid) {
		// TODO Auto-generated method stub
		repository.removeTrainee(tid);
	}
	@Override
	public Trainee gettraineeDetails(int tid) {
		// TODO Auto-generated method stub
		return repository.gettraineeDetails(tid);
	}
	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return repository.updateTrainee(trainee);
	}

}
