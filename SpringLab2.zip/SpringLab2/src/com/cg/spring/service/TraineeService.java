package com.cg.spring.service;

import java.util.List;

import com.cg.spring.bean.Trainee;

public interface TraineeService {
	public List<Trainee> getdomainList() ;
	public Trainee addTraineeDetails(Trainee trainee);
	public List<Trainee> getTraineeList();
	public Trainee gettraineeDetails(int tid);
	public void removeTrainee(int tid);
	public Trainee updateTrainee(Trainee trainee);
}
