package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.bean.Trainee;




@Repository
public class TraineeDaoImpl implements TraineeDao {

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public List<Trainee> getdomainList() {
		// TODO Auto-generated method stub
		TypedQuery<Trainee> query=entityManager.createQuery("from Trainee",Trainee.class);
		List<Trainee> domainlist=query.getResultList();
		return domainlist;
	
	}
	@Override
	public Trainee addTraineeDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		entityManager.flush();
		
		return trainee;
	}
	@Override
	public List<Trainee> getTraineeList() {
		// TODO Auto-generated method stub
		List<Trainee> list;
		TypedQuery<Trainee> query=entityManager.createQuery("from Trainee",Trainee.class);
		list=query.getResultList();
		return list;
	
	}
	@Override
	public void removeTrainee(int tid) {
		// TODO Auto-generated method stub
		Trainee tan=entityManager.find(Trainee.class, tid);
		//BookDetails book=getBookDetails(bookid);
		entityManager.remove(tan);
		entityManager.flush();
	}
	@Override
	public Trainee gettraineeDetails(int tid) {
		// TODO Auto-generated method stub
		Trainee trainee=entityManager.find(Trainee.class, tid);
		return trainee;
	}
	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.merge(trainee);
		entityManager.flush();
		return trainee;
		
	}

}
