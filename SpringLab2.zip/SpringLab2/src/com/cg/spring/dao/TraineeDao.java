package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.bean.Trainee;






public interface TraineeDao {
	public Trainee addTraineeDetails(Trainee trainee);
	public List<Trainee> getdomainList() ;
	public List<Trainee> getTraineeList();
	public void removeTrainee(int tid);
	public Trainee gettraineeDetails(int tid);
	public Trainee updateTrainee(Trainee trainee);
}
