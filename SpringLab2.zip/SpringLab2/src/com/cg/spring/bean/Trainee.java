package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="Trainee")
//@SequenceGenerator(name="tid_id_seq",sequenceName="tid_seq")
public class Trainee {

	@Id
//	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="tid_id_seq")
	
	@Column(name="tid")
	private int id;
	@NotEmpty(message="name can not be blank")
	@Size(max=20,min=4,message="first name >=5 and <=20 chars")
	@Column(name="t_name")
	private String name;
	
	@Column(name="t_domain")
	private String domain;
	
	@Column(name="t_location")
	private String loc;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "Trainee [id=" + id + ", name=" + name + ", domain=" + domain
				+ ", loc=" + loc + "]";
	}
	
}
