package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entities.Author;
import com.cg.spring.entities.BookDetails;

public interface BookRepository {
	public List<Author> getAuthorList();
	public BookDetails addBookDetails(BookDetails book);
	public List<BookDetails> getBookList();
	public BookDetails getBookDetails(int bookid);
	public BookDetails updateBook(BookDetails book);
	public void removeBook(int bookid);
	
}
