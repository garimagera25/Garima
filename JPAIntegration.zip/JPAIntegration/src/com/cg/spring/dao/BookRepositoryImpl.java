package com.cg.spring.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.Author;
import com.cg.spring.entities.BookDetails;
@Repository
public class BookRepositoryImpl implements BookRepository{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Author> getAuthorList() {
		// TODO Auto-generated method stub
//		Query query=entityManager.createQuery("from author");
//		List<Author> authorList=query.getResultList();
		TypedQuery<Author> query=entityManager.createQuery("from Author",Author.class);
		List<Author> authorList=query.getResultList();
		return authorList;
	}

	@Override
	public BookDetails addBookDetails(BookDetails book) {
		// TODO Auto-generated method stub
		entityManager.persist(book);
		entityManager.flush();
		
		return book;
	}

	@Override
	public List<BookDetails> getBookList() {
		// TODO Auto-generated method stub
		List<BookDetails> list;
		TypedQuery<BookDetails> query=entityManager.createQuery("from BookDetails",BookDetails.class);
		list=query.getResultList();
		return list;
	}

	@Override
	public BookDetails getBookDetails(int bookid) {
		// TODO Auto-generated method stub
		BookDetails book=entityManager.find(BookDetails.class,bookid);
		return book;
	}

	@Override
	public BookDetails updateBook(BookDetails book) {
		// TODO Auto-generated method stub
		entityManager.merge(book);
		entityManager.flush();
		return book;
	}

	@Override
	public void removeBook(int bookid) {
		// TODO Auto-generated method stub
		//BookDetails book=entityManager.find(BookDetails.class, bookid);
		BookDetails book=getBookDetails(bookid);
		entityManager.remove(book);
		entityManager.flush();
	}

	

	
}
