package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.BookRepository;
import com.cg.spring.entities.Author;
import com.cg.spring.entities.BookDetails;

@Transactional
@Service
public class BookServiceImpl implements BookService{

	@Autowired
	BookRepository repository;
	@Override
	public List<Author> getAuthorList() {
		// TODO Auto-generated method stub
		return repository.getAuthorList();
	}
	@Override
	public BookDetails addBookDetails(BookDetails book) {
		// TODO Auto-generated method stub
		
		return repository.addBookDetails(book);
		
		
	}
	@Override
	public List<BookDetails> getBookList() {
		// TODO Auto-generated method stub
		return repository.getBookList();
	}
	@Override
	public BookDetails getBookDetails(int bookid) {
		// TODO Auto-generated method stub
		return repository.getBookDetails(bookid);
	}
	@Override
	public BookDetails updateBook(BookDetails book) {
		// TODO Auto-generated method stub
		return repository.updateBook(book);
	}
	@Override
	public void removeBook(int bookid) {
		// TODO Auto-generated method stub
		 repository.removeBook(bookid);
	}
	

}
