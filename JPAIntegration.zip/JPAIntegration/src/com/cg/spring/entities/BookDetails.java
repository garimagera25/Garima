package com.cg.spring.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name="book_id_seq",sequenceName="bookid_seq")
@Table(name="Book_Details")
public class BookDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="book_id_seq")
	@Column(name="Book_ID")
	private int bookId;
	//@Column(name="TITLE")
	private String title;
	@Column(name="AUTHOR_ID")
	private int authorId;
	//@Column(name="PRICE")
	private double price;
	@Column(name="PUB_YEAR")
	private int pubYear;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getPubYear() {
		return pubYear;
	}
	public void setPubYear(int pubYear) {
		this.pubYear = pubYear;
	}
	@Override
	public String toString() {
		return "BookDetails [bookId=" + bookId + ", title=" + title
				+ ", authorId=" + authorId + ", price=" + price + ", pubYear="
				+ pubYear + "]";
	}
	
	
}
