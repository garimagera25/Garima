package RegisterServlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.RegisterUser;
import com.cg.exceptions.RegisterException;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;


@WebServlet("/registeruser")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int option=0;
		
		RegisterService rser=new RegisterServiceImpl();
		 String firstname=	request.getParameter("fname");
		 String lastname=request.getParameter("lname");
		 String password=request.getParameter("pwd");
		 String gender=request.getParameter("gen");
		 String[] skill=request.getParameterValues("skill");
		 String skillset=String.join("," ,skill);
		 String city=request.getParameter("city");
		 RegisterUser reg=new RegisterUser(firstname,lastname,password,gender,skillset,city);
		 String target="";
		 try{
			 rser.registerUser(reg);
			 request.setAttribute("reg", reg);
			 target="success";
		 }catch(RegisterException e)
		 {
			 request.setAttribute("message",e.getMessage());
			 target="error";
		 }
		 try{
			 List<RegisterUser> getUserList() throws RegisterException
		 request.setAttribute("", arg1);
		 }
		 RequestDispatcher disp=request.getRequestDispatcher(target);
		 disp.forward(request, response);
		
//	 response.sendRedirect(target);
	}

}
