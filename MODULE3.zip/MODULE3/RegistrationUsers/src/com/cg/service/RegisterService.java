package com.cg.service;

import java.util.List;

import com.cg.dto.RegisterUser;
import com.cg.exceptions.RegisterException;



public interface RegisterService {
	int registerUser(RegisterUser reg)throws RegisterException;
	public List<RegisterUser> getUserList() throws RegisterException;
}
