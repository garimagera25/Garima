package com.cg.service;


import java.util.List;

import com.cg.dao.RegisterDaoImpl;
import com.cg.dao.RegisterDao;
import com.cg.dto.RegisterUser;
import com.cg.exceptions.RegisterException;

public class RegisterServiceImpl implements RegisterService {

	RegisterDao rdao=new RegisterDaoImpl();

	@Override
	public int registerUser(RegisterUser reg) throws RegisterException {
		// TODO Auto-generated method stub
		return rdao.insertUser(reg);
	}

	@Override
	public List<RegisterUser> getUserList() throws RegisterException {
		// TODO Auto-generated method stub
		return rdao.getUserList();
	}
	

}
