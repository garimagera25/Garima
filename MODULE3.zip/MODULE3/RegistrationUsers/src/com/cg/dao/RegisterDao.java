package com.cg.dao;

import java.util.List;

import com.cg.dto.RegisterUser;
import com.cg.exceptions.RegisterException;

public interface RegisterDao {
	int insertUser(RegisterUser reg) throws RegisterException;
	public List<RegisterUser> getUserList() throws RegisterException;
}
