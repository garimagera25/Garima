package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import com.cg.dto.RegisterUser;
import com.cg.exceptions.RegisterException;

public class RegisterDaoImpl implements RegisterDao {

	Connection conn;
	public RegisterDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int insertUser(RegisterUser reg) throws RegisterException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO RegisteredUsers Values(?,?,?,?,?,?)";
		int ct=0;
		
		try{
		conn=DBUtil.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1,reg.getFirstname());
		pst.setString(2,reg.getLastname());
		pst.setString(3,reg.getPassword());
		pst.setString(4,reg.getGender());
		
		pst.setString(5,reg.getSkillset());
		pst.setString(6,reg.getCity());
		ct=pst.executeUpdate();
		}
		
		catch(SQLException e)
		{
			throw new RegisterException("problem in inserting record"+e.getMessage());
		}
		return ct;
		
		
		
	}
	

	@Override
	public List<RegisterUser> getUserList() throws RegisterException {
		// TODO Auto-generated method stub
		String selQry= "select * from mobiles ";
		List<RegisterUser> userlist= new ArrayList<RegisterUser>();
		try {
			PreparedStatement ps= conn.prepareStatement(selQry);
			ResultSet rs= ps.executeQuery();
			
			while( rs.next()){
				RegisterUser regis= new RegisterUser();
				regis.setFirstname(rs.getString(1));
				regis.setLastname(rs.getString(2));
				regis.setGender(rs.getString(3));
				regis.setPassword(rs.getString(4));
				regis.setSkillset(rs.getString(5));
				regis.setCity(rs.getString(6));
				userlist.add(regis);
			}			
		} catch (SQLException e) {
			throw new RegisterException(e.getMessage());
		}		
		return userlist;
		
	}

	
}
