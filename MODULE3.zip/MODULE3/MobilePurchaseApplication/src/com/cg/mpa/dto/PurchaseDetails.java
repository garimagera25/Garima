package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetails {

	private int purchaseid;
    private	String custName;
    private String mailid;
    private String phoneno;
    private LocalDate purchaseDate;
    private int mobileid;
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseid=" + purchaseid + ", custName="
				+ custName + ", mailid=" + mailid + ", phoneno=" + phoneno
				+ ", purchaseDate=" + purchaseDate + "]";
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public PurchaseDetails() {
		// TODO Auto-generated constructor stub
	}

}
