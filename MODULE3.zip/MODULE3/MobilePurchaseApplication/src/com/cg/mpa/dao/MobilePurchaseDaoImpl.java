package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exceptions.MobileException;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {

	Connection conn;
	

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		List<Mobile> mlist=new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT mobileid,name,price,quantity FROM mobiles";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{	Mobile m=new Mobile();
			m.setMobileid(rst.getInt(1));
			m.setMobileName(rst.getString(2));
			m.setPrice(rst.getDouble(3));
			m.setQuantity(4);
			mlist.add(m);	
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching list");
			// TODO Auto-generated catch block
			
		}
		return mlist;
	}
	private int fetchPurchaseid() throws MobileException{
		String sql=" Select seq_purchase_id.nextval from dual";
		conn=DBUtil.getConnection();
		try {
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(sql);
			rst.next();
			return rst.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("Problem in generating purchase sequence");
		}
		
		
	}


	@Override
	public int insertPurchaseDetail(PurchaseDetails pDetails)
			throws MobileException {
		String sql="Insert into purchasedetails values(?,?,?,?,?,?)";
		pDetails.setPurchaseid(fetchPurchaseid());
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, pDetails.getPurchaseid());
			pst.setString(2, pDetails.getCustName());
			pst.setString(3, pDetails.getMailid());
			pst.setString(4, pDetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setInt(6, pDetails.getMobileid());
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("problem in inserting record");
		}
		
		return pDetails.getPurchaseid();
	}


	@Override
	public Mobile getMobile(int mid) throws MobileException {
		// TODO Auto-generated method stub
		String sql="SELECT mobileid,name,price,quantity FROM mobiles WHERE mobileid=?";
		Mobile mobile =null;
		conn=DBUtil.getConnection();
		try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1, mid);
		ResultSet rst=pst.executeQuery();
		
			if(rst.next())
			{
				mobile=new Mobile();
				mobile.setMobileid(rst.getInt("mobileid"));
				mobile.setMobileName(rst.getString("name"));
				mobile.setPrice(rst.getDouble("price"));
				mobile.setQuantity(rst.getInt("quantity"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MobileException("problem in fetching records");
		}
		return mobile;
	}


	@Override
	public int updateMobileQuantity(int mid) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

}
