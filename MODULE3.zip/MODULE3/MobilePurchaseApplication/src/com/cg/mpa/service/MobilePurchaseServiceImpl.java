package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobilePurchaseDao;
import com.cg.mpa.dao.MobilePurchaseDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.exceptions.MobileException;

public class MobilePurchaseServiceImpl implements MobilePurchaseService {

	MobilePurchaseDao mdao=new MobilePurchaseDaoImpl();

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		
		
		return mdao.getAllMobiles();
	}

	@Override
	public Mobile getMobile(int mid) throws MobileException {
		// TODO Auto-generated method stub
		return mdao.getMobile(mid);
	}

	@Override
	public int insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException {
		// TODO Auto-generated method stub
		mdao.updateMobileQuantity(pDetails.getMobileid());
		return mdao.insertPurchaseDetail(pDetails);
	}

}
