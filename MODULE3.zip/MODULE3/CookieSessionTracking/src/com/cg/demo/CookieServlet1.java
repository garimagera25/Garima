package com.cg.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieServlet1
 */
@WebServlet("/CookieServlet1")
public class CookieServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CookieServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String color=request.getParameter("color");
		String uname="";
		Cookie cArr[]=request.getCookies();
		for(Cookie c:cArr)
		{
			if(c.getName().equals("uname")){
				uname=c.getValue();
			}
		}
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.print("<h1 style='color:"+color+"'>");
				out.print("Welcome"+uname);
				out.print("</h1>");
	}

}
