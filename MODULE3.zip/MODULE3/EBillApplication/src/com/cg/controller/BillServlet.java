package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;






import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;


import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;


@WebServlet({"/admin","/EBillServlet"})
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public BillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 
		EBillService eser=new EBillServiceImpl();
		String target="";
		String url=request.getServletPath();
		switch(url){
		case "/admin":
			String user=request.getParameter("userName");
			String pwd=request.getParameter("PassWord");
			if(user.equals("admin") && pwd.equals("admin"))
			{
				target="Ebill.html";
			}
			else
				target="LOgin.html";
			break;
		case "/EBillServlet":
			System.out.println("in ebillservlet");
			 int cnum=Integer.parseInt(request.getParameter("cNum"));
             double lastmeter=Double.parseDouble(request.getParameter("lMeter"));
    	       double  currmeter=Double.parseDouble(request.getParameter("cMeter"));
    	       double netAmt=0;
    	    	double unitConsumed=0.0;
    		    
    		    try {
    				if(currmeter>lastmeter)
    				{ 
    				  double fixedcharge=100;
    				 unitConsumed=currmeter-lastmeter;
    				  netAmt=(unitConsumed*1.15)+fixedcharge;
    				  BillDetails bdetail=new BillDetails();
    				  System.out.println("in if ");
   				  Consumers c=eser.getConsumers(cnum);
   				  System.out.println("session started");
 				  HttpSession sess=request.getSession(true);
  				  sess.setAttribute("con", c);
   				  System.out.println("in session");
    	    	       bdetail.setCnum(cnum);
    	    	       bdetail.setCurread(currmeter);
    	    	       bdetail.setBill_date(LocalDate.now());
    	    	       bdetail.setNetAmount(netAmt);
    	    	       bdetail.setUnitConsumed(unitConsumed);
    	    	      eser.insertbill(bdetail);
    	    	      
    	    	      request.setAttribute("bdetails", bdetail);
    	    	      target="done";
    	    	      System.out.println("in done");
    	    	      
    				}else
    					
    				{throw new BillException("current reading should be greater than last meter reading"); }
    	    	      
 
    			} catch (Exception e) {
    				// TODO Auto-generated catch block
    				request.setAttribute("message", e.getMessage());
    				target="error";
    			}break;
		}
		
    		    RequestDispatcher disp=request.getRequestDispatcher(target);
    			disp.forward(request,response);
    		         
    				
	}		
	}

			
      
       		
			
    	      
/*	          HttpSession sess=request.getSession(false);
	         
	         BillDetails bill=  (BillDetails) sess.getAttribute("bill");
	          bdetail.setCnum(bill.getCnum());
	          try{
                     
	        	 
 					{
 					
	        	     
 					}
				else
   					{
						
   					//throw new BillException("Customerid does not exist");}
	          catch(BillException e)
	          {String error=e.getMessage();
				request.setAttribute("error", error);
				target="error"; }
	          break;
		}*/
		
	


