package com.cg.dao;

import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;



public interface EBillDao {
	//int insertConsumer(Consumers con) throws BillException;
	int insertbill(BillDetails bill) throws BillException;
	public List<Consumers> SearchConsumer(int cnum) throws BillException;

	public Consumers getConsumers(int id) throws BillException;
}
