package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;


public class EBillDaoImpl implements EBillDao {

	Connection conn;
	
/*	@Override
	public int insertConsumer(Consumers con) throws BillException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO Consumers values(?,?,?)";
		int ct=0;
		
		try{
		conn=DBUtil.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,con.getCnum());
		pst.setString(2,con.getCname());
		pst.setString(3,con.getAddress());
		ct=pst.executeUpdate();
		}
		
		catch(SQLException e)
		{
			throw new BillException("problem in inserting record"+e.getMessage());
		}
		return ct;
		
	}*/

	@Override
	public int insertbill(BillDetails bill) throws BillException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO BillDetails values(seq_bill_num.nextval,?,?,?,?,?)";
		int ct=0;
		
		try{
		conn=DBUtil.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,bill.getCnum());
		pst.setDouble(2,bill.getCurread());
		pst.setDouble(3,bill.getUnitConsumed());
		pst.setDouble(4,bill.getNetAmount());
		LocalDate sysDate=LocalDate.now();
		pst.setDate(5,java.sql.Date.valueOf(sysDate));
		ct=pst.executeUpdate();
		int r= pst.executeUpdate();
		int billid=0;
		if(r==1){
			
				Statement st= conn.createStatement();
				ResultSet rs= st.executeQuery("select seq_bill_num.currval from dual");
				if(rs.next())
					billid=rs.getInt(1);
		}
		}
		
		catch(SQLException e)
		{
			throw new BillException("Invalid consumer number:");
		}
		return ct;
	
	}

	@Override
	public List<Consumers> SearchConsumer(int cnum) throws BillException {
		// TODO Auto-generated method stub
		List<Consumers> conlist=new ArrayList<Consumers>();
		String query="SELECT * from Consumers where Consumer_num=?";
		try{
			Statement statement=conn.createStatement();
			ResultSet resultset=statement.executeQuery(query);
			while(resultset.next())
			{
				Consumers consume =new Consumers();
				consume.setCnum(resultset.getInt(1));
				consume.setCname(resultset.getString(2));
				consume.setAddress(resultset.getString(3));
				conlist.add(consume);
				
			}
			if(conlist.isEmpty()){
				throw new BillException("Consumer id does not match with DB");
			}
		}catch(SQLException e){
			throw new BillException("Consumer id does not match with DB");
		}
		return conlist;
	}

	@Override
	public Consumers getConsumers(int id) throws BillException {
		// TODO Auto-generated method stub
		Consumers consumer= new Consumers();
		String selQry= "select * from Consumers  where Consumer_num=?";
		
		try {
			conn=DBUtil.getConnection();
			PreparedStatement ps= conn.prepareStatement(selQry);
			System.out.println("in dao layer");
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				consumer.setCnum(rs.getInt(1));
				consumer.setCname(rs.getString(2));
				consumer.setAddress(rs.getString(3));
				System.out.println("in dao layer");
			}
			
			
		} catch (SQLException e) {
			throw new BillException(e.getMessage());
		}
		return consumer;
		
	}

}
