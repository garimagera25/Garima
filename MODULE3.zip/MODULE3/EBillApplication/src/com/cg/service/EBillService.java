package com.cg.service;

import java.util.List;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;

public interface EBillService {

	//int insertConsumer(Consumers con) throws BillException;
	int insertbill(BillDetails bill) throws BillException;
	List<Consumers> SearchConsumer(int cnum) throws BillException;
	public Consumers getConsumers(int id) throws BillException;
	//double calcBill(double lastRead, double curRead) throws BillException;
}
