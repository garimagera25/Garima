package com.cg.dto;

import java.time.LocalDate;


public class BillDetails {
	private int bnum;  
	private int cnum; 
	private double curRead; 
	private double unitConsumed;
	private double netAmount; 
	private LocalDate billDate;
	public BillDetails(){}
	public int getBnum() {
		return bnum;
	}
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}
	
	public double getCurread() {
		return curRead;
	}
	public void setCurread(double curread) {
		this.curRead = curread;
	}
	public double getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnitConsumed(double unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public LocalDate getBill_date() {
		return billDate;
	}
	public void setBill_date(LocalDate bill_date) {
		this.billDate = bill_date;
	}
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	
		
	}
	


