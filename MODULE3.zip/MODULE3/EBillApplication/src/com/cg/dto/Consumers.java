package com.cg.dto;

public class Consumers {

	private int cnum;
	private String cname;
	private String  address ;
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Consumers(int cnum,String cname,String  address ) {
		// TODO Auto-generated constructor stub
		this.cnum=cnum;
		this.cname=cname;
		this.address=address;
	}
	public Consumers() {
		// TODO Auto-generated constructor stub
	}

}
