package com.cg.demos;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RegisterServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String ename=request.getParameter("ename");
		String ageStr=request.getParameter("age");
		int age =Integer.parseInt(ageStr);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		if(age>=18 && age<=60)
		{
			//out.print("<h1> Welcome"+ename+"</h1>");}
//			response.setStatus(HttpServletResponse.SC_MOVED_TEMPORARILY);
//			response.setHeader("Location", "http://talent.capgemini.com");or 
//			response.sendRedirect("http://talent.capgemini.com");
			out.print("you will be redirected in 5 sec");
			response.setHeader("Refresh", "5;http://talent.capgemini.com");
			}
			
		else
			{
				//out.print("<h1 style=color:'red'>Invalid age</h1>");
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED,"Invalid age");//401is the error code
			}
			
			
			
		}
	}


