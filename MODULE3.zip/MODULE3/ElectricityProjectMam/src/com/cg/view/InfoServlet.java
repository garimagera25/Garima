package com.cg.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;


@WebServlet("/done")
public class InfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public InfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest 
			request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession sess=request.getSession(false);
		BillDetails bdetail=(BillDetails) request.getAttribute("bdetails");
		Consumers c=(Consumers) request.getAttribute("con");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		 
		  
		out.print("<h1> Welcome :"+c.getCname()+"</h1>");
		//out.print("<h2> consumer number"+bdetail.getCnum()+"</h2>");
		out.print("");
		out.print("<h2> current meter reading"+bdetail.getCurread()+"</h2>");
		out.print("<h2> unit consumed"+bdetail.getUnitConsumed()+"</h2>");
		out.print("<h2> bill amount is"+bdetail.getNetAmount()+"</h2>");
		// TODO Auto-generated method stub
	}

}
