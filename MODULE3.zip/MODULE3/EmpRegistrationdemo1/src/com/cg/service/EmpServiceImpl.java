package com.cg.service;

import com.cg.dao.EmpDao;
import com.cg.dao.EmpDaoImpl;
import com.cg.dto.Employee;
import com.cg.exceptions.EmpException;

public class EmpServiceImpl implements EmpService {

	EmpDao edao=new EmpDaoImpl();
	
	@Override
	public int registerEmp(Employee emp)throws EmpException {
		
		
		return edao.insertEmp(emp);
	}

}
