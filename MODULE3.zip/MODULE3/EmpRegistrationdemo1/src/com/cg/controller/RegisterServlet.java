package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Employee;
import com.cg.exceptions.EmpException;
import com.cg.service.EmpService;
import com.cg.service.EmpServiceImpl;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public RegisterServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmpService eser=new EmpServiceImpl();
		
	 int empno=	Integer.parseInt(request.getParameter("empno"));
	 String ename=request.getParameter("ename");
	 double sal=Double.parseDouble(request.getParameter("sal"));
	 int deptno=Integer.parseInt(request.getParameter("deptno"));
	 //create bean(dto t) object
	 Employee emp=new Employee(empno,ename,sal,deptno);
	 //u can call service to insert into database
	 String target="";
	 try{
		 eser.registerEmp(emp);
		 request.setAttribute("emp", emp);
		 target="success";
	 }catch(EmpException e)
	 {
		 request.setAttribute("message",e.getMessage());
		 target="error";
	 }
	
	// request.setAttribute("emp", emp);//name with value and name should be string
	 RequestDispatcher disp=request.getRequestDispatcher(target);
	 disp.forward(request, response);
	
	}

}
