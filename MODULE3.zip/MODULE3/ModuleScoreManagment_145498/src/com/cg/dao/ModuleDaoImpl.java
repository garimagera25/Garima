package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.AssessmentScore;
import com.cg.dto.Trainees;
import com.cg.exception.ModuleException;



public class ModuleDaoImpl implements ModuleDao {

	Connection conn;
	public long insertAssessmentScore(AssessmentScore assg) throws ModuleException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO AssessmentScore values(?,?,?,?,?,?,?)";
		
		
		try{
			System.out.println("in dao");
		conn=DBUtil.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setLong(1,assg.getTrainee_Id());
		pst.setString(2,assg.getModule_name());
		pst.setInt(3,assg.getMpt());
		pst.setInt(4,assg.getMtt());
		pst.setInt(5, assg.getAss_marks());
		pst.setInt(6,assg.getTotal());
		pst.setInt(7, assg.getGrade());
		pst.executeUpdate();
		
		}
		
		catch(SQLException e)
		{
			throw new ModuleException("problem in inserting training id");
		}
		return assg.getTrainee_Id();
	
	}
	public ModuleDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public List<Trainees> getTraineeId() throws ModuleException{
		// TODO Auto-generated method stub
		List<Trainees> tlist=new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT trainee_id FROM trainees";
		
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{	Trainees t=new Trainees();
			  t.setTraineeid(rst.getLong(1));
			
			
			tlist.add(t);	
		
			}
		} catch (SQLException e) {
			throw new ModuleException("Problem in fetching training id");
			// TODO Auto-generated catch block
			
		}
		return tlist;
	}
	

}
