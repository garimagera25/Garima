package com.cg.dto;

public class AssessmentScore {

	private long trainee_Id;
	private String module_name;
	private int mpt;
	private int mtt;
	private int ass_marks;
	private int total;
@Override
	public String toString() {
		return "AssessmentScore [trainee_Id=" + trainee_Id + ", module_name="
				+ module_name + ", mpt=" + mpt + ", mtt=" + mtt
				+ ", ass_marks=" + ass_marks + ", total=" + total + ", grade="
				+ grade + "]";
	}

private int grade;
	
	

	
	public int getMpt() {
		return mpt;
	}

	public void setMpt(int mpt) {
		this.mpt = mpt;
	}

	public int getMtt() {
		return mtt;
	}

	

	public void setMtt(int mtt) {
		this.mtt = mtt;
	}

	

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	
	
	public AssessmentScore() {
		// TODO Auto-generated constructor stub
	}

	

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public long getTrainee_Id() {
		return trainee_Id;
	}

	public void setTrainee_Id(long trainee_Id) {
		this.trainee_Id = trainee_Id;
	}

	public String getModule_name() {
		return module_name;
	}

	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}

	public int getAss_marks() {
		return ass_marks;
	}

	public void setAss_marks(int ass_marks) {
		this.ass_marks = ass_marks;
	}

}
