package com.cg.service;


import java.util.List;

import com.cg.dao.ModuleDao;
import com.cg.dao.ModuleDaoImpl;
import com.cg.dto.AssessmentScore;
import com.cg.dto.Trainees;
import com.cg.exception.ModuleException;

public class ModuleServiceImpl implements ModuleService{

	ModuleDao mdao=new ModuleDaoImpl();
	public ModuleServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public long insertAssessmentScore(AssessmentScore assg)
			throws ModuleException {
		// TODO Auto-generated method stub
		return mdao.insertAssessmentScore(assg);
	}
	@Override
	public List<Trainees> getTraineeId() throws ModuleException {
		// TODO Auto-generated method stub
		return mdao.getTraineeId();
	}

	
	
	}


