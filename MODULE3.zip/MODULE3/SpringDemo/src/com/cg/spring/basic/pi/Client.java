package com.cg.spring.basic.pi;


import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.spring.basic.bean.Employee;


@SuppressWarnings("deprecation")
public class Client {

	public static void main(String[] args) {
	//	Employee emp=new Employee();//reference emp in bean tag in xml
         Resource resource=new ClassPathResource("beans.xml");
		XmlBeanFactory factory=new XmlBeanFactory(resource);	
		Employee emp=(Employee)factory.getBean("emp");
		System.out.println(emp.getEmpId());
		System.out.println(emp.getEmpName());
		System.out.println(emp.getSalary());
		System.out.println("skills:"+emp.getSkills());
		
		
	}
	

}
