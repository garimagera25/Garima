package com.cg.spring.basic.bean;

import java.util.ArrayList;

public class Employee {

	private int empId;
	private String empName;
	private double salary;
	private ArrayList<String> skills;
	
	public Employee(int id,String name,double sal)
	{
		empId=id;
		empName=name;
		salary=sal;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", salary=" + salary + "]";
	}



	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		System.out.println("in setemp method");
		this.empName = empName;
	}



	public double getSalary() {
		return salary;
	}



	public void setSalary(double salary) {
		this.salary = salary;
	}

	public ArrayList<String> getSkills() {
		return skills;
	}

	public void setSkills(ArrayList<String> skills) {
		this.skills = skills;
	}



	
	
	
/*	<property name="empId" value="1274"></property>
	<property name="empName" value="smitha"></property>
	<property name="salary" value="34900"></property>
*/
}
