package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;


@WebServlet(urlPatterns={"/BillServlet"})
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
       private int fixedcharge=100;
    
    public BillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getServletPath();
		switch(action)
		{ 
		case "/BillServlet":
			BillDetails bill=new BillDetails();
		                    PrintWriter out=response.getWriter();
		                   int cnum=Integer.parseInt(request.getParameter("cnum"));
		                    double lastmeter=Double.parseDouble(request.getParameter("lmeter"));
		           	       double  currmeter=Double.parseDouble(request.getParameter("cmeter"));
//		           	       EBillService bser=new EBillServiceImpl();
//		           	       double netAmount=bser.calcBill(lastmeter, currmeter);
		        	    double unitConsumed=0.0;
		        		unitConsumed=lastmeter-currmeter;
		        		double netAmt=0;
		        		netAmt=(unitConsumed*1.15)+fixedcharge;

			
			bill.setCnum(cnum);
            bill.setCurread(currmeter);
            bill.setBill_date(LocalDate.now());
            bill.setNetAmount(netAmt);
            bill.setUnitConsumed(unitConsumed);
            EBillService bser=new EBillServiceImpl();
            try{
            	bser.insertbill(bill);
            	List<Consumers> consumerList=bser.SearchConsumer(cnum);
            	request.getSession().setAttribute("list",consumerList);
            	response.sendRedirect("ShowDetails");
            }catch(BillException e)
            {
            	
            }break;
		}
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request,response);
		
	}

		
		
	}


