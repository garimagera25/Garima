package com.cg.service;

import java.util.List;

import com.cg.dao.EBillDao;
import com.cg.dao.EBillDaoImpl;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;

public class EBillServiceImpl implements EBillService {

	EBillDao edao=new EBillDaoImpl();
	

/*	@Override
	public int insertConsumer(Consumers con) throws BillException {
		// TODO Auto-generated method stub
		return edao.insertConsumer(con);
	}*/

	@Override
	public int insertbill(BillDetails bill) throws BillException {
		// TODO Auto-generated method stub
		return edao.insertbill(bill);
	}


	@Override
	public List<Consumers> SearchConsumer(int cnum) throws BillException {
		// TODO Auto-generated method stub
		return edao.SearchConsumer(cnum);
	}

//	@Override
//	public double calcBill(double lastRead, double curRead)
//			throws BillException {
//		// TODO Auto-generated method stub
//		int fixedCharge=100;
//		double lR=lastRead;
//		double cR= curRead;
//				return netAmt,unitConsumed;
//		
//	}

}
