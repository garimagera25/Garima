package com.cg.dto;

public class UserInput {

	private int cNum;
	private double lMeter;
	private double cMeter;
	private String userName;
	private String PassWord;
	public int getcNum() {
		return cNum;
	}
	public void setcNum(int cNum) {
		this.cNum = cNum;
	}
	public double getlMeter() {
		return lMeter;
	}
	public void setlMeter(double lMeter) {
		this.lMeter = lMeter;
	}
	public double getcMeter() {
		return cMeter;
	}
	public void setcMeter(double cMeter) {
		this.cMeter = cMeter;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return PassWord;
	}
	public void setPassWord(String passWord) {
		this.PassWord = passWord;
	}
	
	public UserInput() {
	
		// TODO Auto-generated constructor stub
	}

}
