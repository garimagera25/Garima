package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;


public class EBillDaoImpl implements EBillDao {

	Connection conn;
	
/*	@Override
	public int insertConsumer(Consumers con) throws BillException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO Consumers values(?,?,?)";
		int ct=0;
		
		try{
		conn=DBUtil.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,con.getCnum());
		pst.setString(2,con.getCname());
		pst.setString(3,con.getAddress());
		ct=pst.executeUpdate();
		}
		
		catch(SQLException e)
		{
			throw new BillException("problem in inserting record"+e.getMessage());
		}
		return ct;
		
	}*/

	public int insertbill(BillDetails bill) throws BillException {
		// TODO Auto-generated method stub
		String sql="INSERT INTO BillDetails values(seq_bill_num.nextval,?,?,?,?,?)";
		int ct=0;
		int billid=0;
		
		try{
		conn=DBUtil.getConnection();
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,bill.getCnum());
		pst.setDouble(2,bill.getCuread());
		pst.setDouble(3,bill.getUnitconsumed());
		pst.setDouble(4,bill.getNetamount());
		LocalDate sysDate=LocalDate.now();
		pst.setDate(5,java.sql.Date.valueOf(sysDate));
		ct=pst.executeUpdate();
		int r= pst.executeUpdate();
		System.out.println("executed");
		
		if(r==1){
			
				Statement st= conn.createStatement();
				ResultSet rs= st.executeQuery("select seq_bill_num.currval from dual");
				if(rs.next())
					billid=rs.getInt(1);
		}else
			throw new BillException("consumer number does not exist");
		}
		
		catch(SQLException e)
		{
			throw new BillException("no bill details for consumer number:"+bill.getCnum());
		}
		return billid;
	
	}
	@Override
	public Consumers SearchConsumer(int cnum) throws BillException {
		// TODO Auto-generated method stub
		Consumers consumer= new Consumers();
		String selQry="SELECT * from Consumers where Consumer_num=?";
		try{
			conn=DBUtil.getConnection();
			PreparedStatement ps= conn.prepareStatement(selQry);
			ps.setInt(1, cnum);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				
				consumer.setCnum(rs.getInt(1));
				consumer.setCname(rs.getString(2));
				consumer.setAddress(rs.getString(3));
				
				
			}
			
		}catch(SQLException e){
			throw new BillException("Consumer id does not match with DB");
		}
		return consumer;
	}

	@Override
	public Consumers getConsumers(int id) throws BillException {
		// TODO Auto-generated method stub
		Consumers consumer= new Consumers();
		String selQry= "select * from Consumers  where Consumer_num=?";
		
		try {
			conn=DBUtil.getConnection();
			PreparedStatement ps= conn.prepareStatement(selQry);
			System.out.println("in dao layer");
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				consumer.setCnum(rs.getInt(1));
				consumer.setCname(rs.getString(2));
				consumer.setAddress(rs.getString(3));
				System.out.println("in dao layer");
			}
			
			
		} catch (SQLException e) {
			throw new BillException(e.getMessage());
		}
		return consumer;
		
	}
	@Override
	public List<Consumers> getConsumerList() throws BillException {
	
		String selQry= "select * from Consumers ";
		List<Consumers> consumerlist= new ArrayList<Consumers>();
		try {
			conn=DBUtil.getConnection();
			PreparedStatement ps= conn.prepareStatement(selQry);
			
			ResultSet rs= ps.executeQuery();
			
			while( rs.next()){
				Consumers co= new Consumers();
				co.setCnum(rs.getInt(1));
				co.setCname(rs.getString(2));
				
				co.setAddress(rs.getString(3));
				consumerlist.add(co);
			}			
		} catch (SQLException e) {
			throw new BillException(e.getMessage());
		}		
		return consumerlist;
	}
	@Override
	public List<BillDetails> getBills(int id) throws BillException {
		// TODO Auto-generated method stub
		
		String selQry= "select * from BillDetails Where Consumer_num=? ";
		List<BillDetails> billlist= new ArrayList<BillDetails>();
		 
		try {
			conn=DBUtil.getConnection();
			PreparedStatement ps= conn.prepareStatement(selQry);
			System.out.println("in dao layer");
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			while( rs.next()){
				BillDetails bill=new BillDetails();
				bill.setBnum(rs.getInt(1));
				bill.setCnum(rs.getInt(2));
				
				bill.setCuread(rs.getDouble(3));
				bill.setUnitconsumed(rs.getDouble(4));
				bill.setNetamount(rs.getDouble(5));
				Instant instant=Instant.ofEpochMilli(rs.getDate(6).getTime());
				LocalDateTime localDateTime=LocalDateTime.ofInstant(instant,ZoneId.systemDefault());
				LocalDate localDate=localDateTime.toLocalDate();
				bill.setBilldate(localDate);
				
				billlist.add(bill);
				System.out.println("in dao layer");
			}
			
			
		} catch (SQLException e) {
			throw new BillException(e.getMessage());
		}
		return billlist;
		
	}
	

}
