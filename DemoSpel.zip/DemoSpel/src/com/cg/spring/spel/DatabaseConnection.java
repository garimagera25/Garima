package com.cg.spring.spel;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("dbconnection")
public class DatabaseConnection {
@Value("#{props['url']}")//no need of xml configuration
private String url;
@Value("#{props['userName']}")
private String	userName;
@Value("#{props['password']}")
private String	password;
private String	driver;
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getDriver() {
	return driver;
}
public void setDriver(String driver) {
	this.driver = driver;
}
/*** 	 <util:properties id="props" location="classpath:jdbc.properties"></util:properties>
<bean id="dbconnection" class="com.cg.spring.spel.DatabaseConnection">
 <property name="url" value="#{props['url']}"></property>
<property name="userName" value="#{props['username']}"></property>
<property name="password" value="#{props['password']}"></property>
</bean>**/
}
