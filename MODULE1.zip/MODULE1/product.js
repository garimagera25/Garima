var productArray = [["Electronics","Television","Laptop", "Phone"],["Soap","Powder"]];


fuction choosecategory()
{
 var category=frm2.category.value;
 var List=frm2.productList;
 if(category=='Electronics') 
 {
  for(i=0; i<productArray[0].length;i++)
  {var option =new option();
  option.text=productArray[0][i];
  list.options[i]=option;
  }
}
else
for(i=0; i<productArray[1].length;i++)
  {var option =new option();
  option.text=productArray[1][i];
  list.options[i]=option;
  }