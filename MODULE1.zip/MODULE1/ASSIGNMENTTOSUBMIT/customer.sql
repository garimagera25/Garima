create table customer1
(custid number(5)              PRIMARY KEY,
 cust_name varchar2(20)        NOT NULL,
 address1 varchar2(30),
 address2 varchar2(30)
 );
 
 ALTER table customer1
 MODIFY (cust_name varchar(30));
 
 ALTER table customer1
 ADD(gender   varchar2(1),
     age     number(3),
	 phoneno number(10),
	 EMAIL   varchar2(30));
	 
	 
ALTER table customer1
DROP COLUMN EMAIL ;


create table ACCOUNTMASTER1
(accno number(10,2)  CONSTRAINT Acc_PK  PRIMARY KEY,
 custID number(5) CONSTRAINT custid_fk REFERENCES customer1(custID),
 accounttype varchar2(3),
 Ledbalance number(10,2)    NOT NULL
 );
 
 ALTER TABLE ACCOUNTMASTER1 ADD CHECK(accounttype='NRI' OR accounttype="IND");
 
 ALTER TABLE ACCOUNTMASTER1 CONSTRAINT Balance_Check CHECK(Ledbalance>5000);
 
 
 
 CREATE SEQUENCE seq_customer START WITH 
 INCREMENT BY 1;
 INSERT INTO customer1 VALUES(seq_customer.NEXTVAL,'1000','Smith','46 Lane 1' ,'New York','M','35','7890893433');
 INSERT INTO customer1 VALUES(seq_customer.NEXTVAL,'1001','	Jack','89 Lane 9' ,'Washington','M','39','6690233433');
 INSERT INTO customer1 VALUES(seq_customer.NEXTVAL,'1002','Mary','78 Lane 5' ,'Chicago	F','32'	,'8990893433');
 INSERT INTO customer1 VALUES(seq_customer.NEXTVAL,'1003',	'James','46Lane 8','New York','M','42','6690893123');
 
 CREATE SEQUENCE seq_ACCOUNTMASTER1 START WITH 2001
 INCREMENT BY 1;
 INSERT INTO ACCOUNTMASTER1 VALUES(seq_ACCOUNTMASTER1.NEXTVAL,'2001	','1003','NRI'	,'5001');
INSERT INTO ACCOUNTMASTER1 VALUES(seq_ACCOUNTMASTER1.NEXTVAL,'2002'	,'1001'	,'IND','7000');
INSERT INTO ACCOUNTMASTER1 VALUES(seq_ACCOUNTMASTER1.NEXTVAL, '2003	','1000'	,'IND	','9000');
INSERT INTO ACCOUNTMASTER1 VALUES(seq_ACCOUNTMASTER1.NEXTVAL, '2004','1002','NRI','4000');

UPDATE table ACCOUNTMASTER1 
SET Ledbalance='8000' WHERE  accno='2004' ;

UPDATE table ACCOUNTMASTER1 
SET accounttype ='IND' WHERE  accno='2004' ;

DELETE FROM ACCOUNTMASTER1 WHERE accno='2004' ;

SELECT cust_name,Ledbalance from customer1 C ,ACCOUNTMASTER1 A where C.custid=A.custID AND accounttype='IND';

SELECT Ledbalance from customer1 C ,ACCOUNTMASTER1 A where C.custid=A.custID AND gender='M';
SELECT * from ACCOUNTMASTER1 A natural join customer1 C WHERE age<40;




