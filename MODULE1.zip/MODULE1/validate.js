var qArray = [["BSc","BA","BCom"],["MSc","MCA","MCom"]];


   function populatequalification(){
   var grad=frm1.rdGrad.value;
    var qualification= frm1.txtqual;
    /*var grad=document.getElementById("rdGrad").value;*/
    if(grad=='UG')
  {for(i=0;i<qArray[0].length;i++) 
   {var option=new Option();
    option.text=qArray[0][i];
   qualification.options[i]=option;
}
}else
{for(i=0;i<qArray[1].length;i++) 
{
  var option= new Option();
  option.text=qArray[1][i];
  qualification.options[i]=option;}
}
}
function showData()
{ var win =window.open();
  var uname =frm1.txtuname.value;
  var dobStr =frm1.txtdob.value;
  var phone=frm1.txtphone.value;
  var email=frm1.txtEmail.value;
  var qualification=frm1.txtqual.value;
  var grad= frm1.rdGrad.value;
  
  var today= new Date();
  var dob= new Date(dobStr);
  var age= today.getYear()-dob.getYear();
  
  
  win.document.write("<br/> NAME:" +uname);
  win.document.write("<br/> PHONE" +phone);
  win.document.write("<br/> EMAIL" +email);
  win.document.write("<br/> QUALIFICATION"+qualification);
  win.document.write("<br/> GRADUATION" +grad);
  win.document.write("<br/> AGE:" +age+ "years");
  
}
