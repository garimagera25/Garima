function showData()
{
  var title =EMPLOYEE.txttitle.value;
  var firstname=EMPLOYEE.txtfname.value;
  var lastname=EMPLOYEE.txtlname.value;
  alert("all data for" +title+firstname+lastname+"entered successfully");
}
