create table Departments
(Department_Code number(5)    PRIMARY KEY,
 Department_Name varchar2(15)        
 );
 

 INSERT INTO Departments VALUES('10','Admin');
 INSERT INTO Departments VALUES('20','HR');
 INSERT INTO Departments VALUES('30','Finance');
 INSERT INTO Departments VALUES('40','Sales');
 INSERT INTO Departments VALUES('50','Marketing');
 
 
 EMPLOYEES
 create table Employees
(Employees_Code number(5)    PRIMARY KEY,
 Employees_Name varchar2(15)    
 Date_of_Joining date
 Salary number(5)
 Grade   varchar(2)
 Department_Code number(5) CONSTRAINT  Department_Code_fk REFERENCES customer1( Department_Code)
 );
 
 INSERT INTO Employees VALUES('101','Preetam','10-Jan-2010','18000','A','20');
 INSERT INTO Employees VALUES('102','Akash','10-Nov-2005','48000','C','10');
 INSERT INTO Employees VALUES('103','Kishore','19-Dec-2005','42000','C','40');
 INSERT INTO Employees VALUES('104','Reena','23-Jun-2006','33000','B','20');
 INSERT INTO Employees VALUES('105','Kailash','05-Feb-2004','36000','C','30');
 
 3. SELECT Employees_Code,Date_of_Joining,Department_Name,Employees_Name from Departments D,Employees E WHERE D.Department_Code=E.Employees;
 1. SELECT Employees_Code,Employees_Name,Date_of_Joining,Salary from Departments WHERE Employees_Name LIKE K% ; 
 4. SELECT Employees_Name from Employees where Department_Code IN(10,20,30);