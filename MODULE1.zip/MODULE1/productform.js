var productArray = [["Television","Laptop", "Phone"],["Soap","Powder"]];
var price=0;

function choosencategory()
{
 var category=productForm.category.value;  
 var productList=productForm.productList;
 if(category=='Electronics') 
 {
  for(i=0; i<productArray[0].length;i++)
  {var option =new Option();
  option.text=productArray[0][i];
  productList.options[i]=option;
 }
 }
 else
 {
 for(i=0; i<productArray[1].length;i++)
  {var option =new Option();
  option.text=productArray[1][i];
  productList.options[i]=option;
  }
  }
  }
  
  function chooseproduct()
  {
  var productselected=productForm.productList.value;
  
  
  
  if(productselected=="Television")
  {
   price=20000;
   
  }
  
  if(productselected=="Laptop")
  {
   price=30000;
  }
  if(productselected=="Phone")
  {
   price=10000;
  }
  if(productselected=="Soap")
  {
   price=40;
  }
  if(productselected=="Powder")
  {
   price=90;
  }
  return price;
  }
  
   var total_price;
   function calculateprice()
   { 
  
   var quantityselected=productForm.Quantity.value;
   var t= chooseproduct();
   total_price= t*quantityselected;
   productForm.total_price.value=total_price;
   
   }
   
   
   