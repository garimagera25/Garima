package com.capgemini.loanapp.service;

import com.capgemini.loanapp.bean.Customer;
import com.capgemini.loanapp.bean.Loan;
import com.capgemini.loanapp.dao.ILoanDao;
import com.capgemini.loanapp.dao.LoanDao;
import com.capgemini.loanapp.exception.LoanAppException;


public class LoanService implements ILoanService {

	ILoanDao dao;
	public LoanService(){
			dao= new LoanDao();
	}
	@Override
	public long applyLoan(Loan loan) throws LoanAppException {
		// TODO Auto-generated method stub
		return dao.applyLoan(loan);
	}

	

	@Override
	public long insertCust(Customer cust) throws LoanAppException {
		// TODO Auto-generated method stub
		return dao.insertCust(cust);
	}

	@Override
	public double calculateEMI(double amount, int duration)
			throws LoanAppException {
		// TODO Auto-generated method stub
		
		return dao.calculateEMI(amount, duration);
	
	}

}
