package com.capgemini.loanapp.service;

public interface IValidationService {
	public boolean validateCustomerName(String name);
	public boolean validateMailId(String mailid);
	public boolean validateMobileNo(String mobno);
	public boolean validateAddress(String add);
}
