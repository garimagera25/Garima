package com.capgemini.loanapp.bean;

public class Loan {
	private long Loan_id;
	private double Loan_amt;
	private long Cust_id;
	private int Duration ;
	public long getLoan_id() {
		return Loan_id;
	}
	public void setLoan_id(long loan_id) {
		Loan_id = loan_id;
	}
	public double getLoan_amt() {
		return Loan_amt;
	}
	public void setLoan_amt(double loan_amt) {
		Loan_amt = loan_amt;
	}
	public long getCust_id() {
		return Cust_id;
	}
	public void setCust_id(long cust_id) {
		Cust_id = cust_id;
	}
	public int getDuration() {
		return Duration;
	}
	public void setDuration(int duration) {
		Duration = duration;
	}
}
