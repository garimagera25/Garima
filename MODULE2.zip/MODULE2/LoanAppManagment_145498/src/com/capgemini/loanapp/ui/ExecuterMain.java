package com.capgemini.loanapp.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.loanapp.bean.Customer;
import com.capgemini.loanapp.bean.Loan;
import com.capgemini.loanapp.exception.LoanAppException;
import com.capgemini.loanapp.service.ILoanService;
import com.capgemini.loanapp.service.IValidationService;
import com.capgemini.loanapp.service.LoanService;
import com.capgemini.loanapp.service.ValidationService;



public class ExecuterMain {
public static void main(String[] args) {
	PropertyConfigurator.configure("resources/log4j.properties");
	Customer customer=new Customer();
	ILoanService service=new LoanService();
	Loan loan=new Loan();
	IValidationService vservice=new ValidationService();
	Logger logger=Logger.getLogger(ExecuterMain.class);
	Scanner sc= new Scanner(System.in);
	int option=0;
	do{
		System.out.println("Loan app welcomes you");
		System.out.println("1. Register Customer ");
		System.out.println("2.Exit ");
	   System.out.println("Enter your Choice .");
	   option= sc.nextInt();
	    switch(option){
	    case 1 :
	    	do{
	    	System.out.println("enter customer name");
	    	String name =sc.next();
	    	boolean res=vservice.validateCustomerName(name);
			if(res==true)
			{
				customer.setCust_name(name);
				break;
			}
             else
				
				System.out.println("Name should contain only alphabets");
			}while(true);
	    	do{
	    	System.out.println("Enter Address : ");
			String add= sc.next();
			boolean res=vservice.validateCustomerName(add);
			if(res==true)
			{
				customer.setAddress(add);
				break;
			}
             else
				
				System.out.println("address should contain only alphabets");
			}while(true);
	    	do{
				System.out.println("Enter Mail id : ");
				String mailid= sc.next();
				boolean res= vservice.validateMailId(mailid);
				if(res==true)
					{
					customer.setEmail(mailid);
						break;
					}
					else
						System.out.println("Mail id as: abcd@capgemini.com ");
				}while(true);
	    	do{
				System.out.println("Enter mobile No :");
				String mobno= sc.next();
				boolean res=vservice.validateMobileNo(mobno);
				if(res)
				{
					customer.setMobileNo(mobno);
					break;
				}
				else
					System.out.println("Mobile no shoule be 10 digit.");
			}while(true);
			
			
			
			try {
				long custid= service.insertCust(customer);
				
				System.out.println("customer information added successfully : "+ custid );
				logger.info("customer information added successfully : "+ custid );
			} catch (LoanAppException e) {
				
				System.out.println(e.getMessage());
				logger.error(e.getMessage());
			}
			System.out.println("1. register for loan request");
			System.out.println("2.exit");
			System.out.println("You wnat to take loan or not ");
			option=sc.nextInt();
	        switch(option)
	        {
	        case 1:System.out.println("enter your customer id");
	              long custid=sc.nextLong();
	               System.out.println("enter loan amount");
	               double amount=sc.nextDouble();
	               System.out.println("enter duration in years");
	               int duration=sc.nextInt();
	               loan.setCust_id(custid);
	               loan.setLoan_amt(amount);
	               loan.setDuration(duration);
	               try
	               {   
	            	   
	            	  double emi= service.calculateEMI(amount, duration);
	            	   System.out.println("for loan amount=" +amount+ "and"+duration+
	            			           "years duration Your emi per month is"+emi);
	            	   logger.info("for loan amount=" +amount+ "and"+duration+
        			           "years duration Your emi per month is"+emi);
	            	   int choice=0;
	            	   System.out.println("do u still want to apply for loan ??");
	            	   System.out.println("press 1 to apply for loan");
	            	   System.out.println("press 2 for exit");
	            	   System.out.println("enter your choice");
	            	   choice= sc.nextInt();
	            	   
	            	   
	            	   switch(choice)
	            	   {
	            	   case 1: long loanid=service.applyLoan(loan);
	            		           System.out.println("your loan request has been generated"+loanid);
	            		           logger.info("your loan request has been generated"+loanid);
	            	   case 2:   System.out.println("your loan request is not yet generated");
	            	             logger.info("your loan request is not yet generated");
	            	   }//end of switch
	            	   
	            	   
	               }catch (LoanAppException e) {
	   				
	   				System.out.println(e.getMessage());
	   			     logger.error(e.getMessage());
	   			   }break;
	        case 2:
	        	   break;
			        default :System.out.println("thank you ");
			        logger.info("thank you ");
	        }
			
			break;
	    case 2:
	    	break;
		default :System.out.println("process terminated ");
		          logger.info("process terminated");
	    	
	    	 }//end of main switch
}while(option!=3);//end of while
}//end of main method
}//end of class
