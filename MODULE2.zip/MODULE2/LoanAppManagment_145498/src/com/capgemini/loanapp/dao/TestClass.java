package com.capgemini.loanapp.dao;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.loanapp.exception.LoanAppException;



public class TestClass {
@Test
public void testinputs()
{  ILoanDao dao=new LoanDao();
  try{
	 int list= dao.validate(10007,Renuka,Delhi,renuka@capgemini.com,1111111111);
	 Assert.assertTrue(list!=0);
  }catch(LoanAppException e)
  {
	  e.printStackTrace();
	  
  }
     
	}

}
