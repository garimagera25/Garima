package com.capgemini.loanapp.dao;

import com.capgemini.loanapp.bean.Customer;
import com.capgemini.loanapp.bean.Loan;
import com.capgemini.loanapp.exception.LoanAppException;

public interface ILoanDao {
  
	public long applyLoan(Loan loan) throws LoanAppException;
	public long insertCust(Customer cust) throws LoanAppException;
	public Customer validateCustomer(Customer customer) throws LoanAppException;
	public double calculateEMI(double amount, int duration)throws LoanAppException; 
}
