package junitdemo;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import junit.framework.Assert;

public class TestCalculator2 {
	static Calculator calc;
	@BeforeClass
	public static void createObject()
	{
		System.out.println("in ceate object method ");
		calc=new Calculator();
	}
	@Test
	public void testMultiply()
	{
		int res=calc.multiply(4, 6);
	}
	@Ignore
	@Test
	public void testSubtract()
	{
//		Calculator calc=new Calculator();
	    int res=calc.subtract(13, 8);
	    Assert.assertEquals(5,res);

	}
	@Test
	public void testGetMax()
	{
//		Calculator calc=new Calculator();
		 int res=calc.getMax(3, 8);
		  Assert.assertEquals(8,res);
		}
	@Test
	public void testAdd()
	{
//		Calculator calc=new Calculator();
		int res=calc.add(3, 8);
		Assert.assertEquals(11,res);
				
	}
}
