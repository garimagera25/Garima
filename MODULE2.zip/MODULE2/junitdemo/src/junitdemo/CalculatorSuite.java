package junitdemo;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
@Suite.SuiteClasses({TestCalculator2.class,TestCalculator2.class})
public class CalculatorSuite {

}
