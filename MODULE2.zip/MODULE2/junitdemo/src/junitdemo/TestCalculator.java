package junitdemo;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

public class TestCalculator {
	Calculator calc;
	@Before
	public void createObject()
	{
		System.out.println("in ceate object method ");
		calc=new Calculator();
	}
	@AfterClass
	public static void cleanUp()
	{
		System.out.println("clean up");
	}
@Test
public void testAdd()
{
//	Calculator calc=new Calculator();
	int res=calc.add(3, 8);
	Assert.assertEquals(11,res);
			
}
	@Test
public void testSubtract()
{
//	Calculator calc=new Calculator();
    int res=calc.subtract(13, 8);
    Assert.assertEquals(5,res);

}
	@Test
public void testGetMax()
{
//	Calculator calc=new Calculator();
	 int res=calc.getMax(3, 8);
	  Assert.assertEquals(8,res);
	}
}