package junitdemo;

import java.util.Arrays;
import java.util.Collection;
import org.junit.runners.Parameterized;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized.Parameters;
@RunWith(Parameterized.class)
public class CalculatorParamTest {
	private int input1,input2;
	private int expected;
	
	public CalculatorParamTest(int in1,int in2,int exp)
	{
		input1=in1; 
		input2=in2;
		expected=exp;
	}
	@Parameters
public static Collection data(){
return Arrays.asList(new Object[][] {{1,3,3},{0,0,0},{-2,-2,4},{-2,2,-4}});
}
	@Test()
	public void testMultiply()
	{
		Calculator calc=new Calculator();
	System.out.println("testing multiply method on:"+input1+""+input2);
	int res=calc.multiply(input1, input2);
	Assert.assertEquals(expected, res);
		
	}
	
	
}