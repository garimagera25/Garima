import java.util.Comparator;
public class CompImp1 implements Comparator<Person>{
@Override
public int compare(Person person1.Person person2)
{
	String name1=person1.getName();
	String name2
	return name1.compareTo(name2);
	}
}
