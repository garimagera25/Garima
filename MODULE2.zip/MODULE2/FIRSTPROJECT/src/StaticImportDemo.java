import static java.lang.Math.PI;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public class StaticImportDemo {
public static void main(String[] args) {
	
	double radius =5.7;
	double area= PI* radius*radius;
	System.out.println(area);
	
	double sq=sqrt(6);
	System.out.println(sq);
	
	double res= pow(3,2);
	System.out.println(res);
}
}

