import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class DemoOnDate {
public static void main(String[] args) {
	LocalDate date= LocalDate.now();
	System.out.println("today is"+date);
	/*LocalDate date2=LocalDate.of(2000,4,25);
	System.out.println(date2);
	Month mon=date.getMonth();
	String name=mon.name();
	//int num=mon.getValue();
	System.out.println("month name:"+name);
	int yr=date.getYear();
	System.out.println("year:"+yr);
	int day=date.getDayOfMonth();
	System.out.println("dau:"+day);
	DayOfWeek dayOfWeek=date.getDayOfWeek();
	String dayname=dayOfWeek.name();
	System.out.println("dayname:"+dayname);
	*/
	LocalDate dt1=date.plusDays(3);
	System.out.println("date after 3 days"+dt1);
	LocalDate dt2=date.plusMonths(3);
	System.out.println("months after adding 3"+dt2);
	LocalDate dt= date.withYear(2016);//month n date remain same
	System.out.println(dt);
	LocalDate dt3=date.withDayOfMonth(29);
	System.out.println(dt3);
	boolean res=date.isLeapYear();
	System.out.println("is it a leap year"+res);
	LocalDate dt4=LocalDate.of(2000, 3, 10);
	LocalDate dt5=LocalDate.of(2015, 4, 10);
	boolean res1=dt4.isAfter(dt5);//isBefore have same syntax
	System.out.println(res1);
	
	//to get the interval between two dates
	
	LocalDate dt6=LocalDate.of(2010,10,23);
	LocalDate dt7=LocalDate.of(2010,11,5);
	Period period=Period.between(dt6, dt7);
	System.out.println(period);
	
	//Period period=Period.of(3,2,10);
	//System.out.println(period);
	//Duration duration=Duration.ofHours(4);
	
	LocalDateTime time1=LocalDateTime.of(2010, 03,1,10,20,00,00);
	LocalDateTime time2=LocalDateTime.of(2010, 03,1,4,20,25,00);
	Duration duration=Duration.between(time1, time2);
	System.out.println(duration);
	
	
	Scanner sc=new Scanner(System.in);
	System.out.println("enter date(dd/mm/yyyy)");
	String dt8=sc.next();
	sc.close();
	
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate dat=LocalDate.parse(dt8,formatter);
	System.out.println(dat);
	//DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy, MMMM ,dd -EE");//-e vl show day number
	//String formattedDate=formatter.format(date);
	//System.out.println(formattedDate);
	
	
}
}
