
public class DEMO {                                                                                                                                          
	
	
	
	 public static void main(String[] args)
	{ System.out.println(args[0]);
	   System.out.println(args[1]);
	   //System.out.println(args[0]+args[1]);
	   int a =Integer.parseInt(args[0]);
	   int b=Integer.parseInt(args[1]);//to convert string into integer
	   System.out.println(a+b);
       //type casting
	   
	   int c=18;
       int d=5;
       float res=c/d;
       System.out.println(res);
	 }
	}
	

