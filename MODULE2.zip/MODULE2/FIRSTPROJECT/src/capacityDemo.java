
import java.util.HashSet;
import java.util.TreeSet;


public class capacityDemo {
	public static void main(String[] args) {
		
	//HashSet<String> set=new HashSet<>();
		TreeSet<String> set=new TreeSet<>();//sorted set
	set.add("Hello");
	set.add("renuka");
	//boolean res=set.add("Servlet");
	//System.out.println(res);
	set.add("Hejko");
	set.add("jdbc");
//	res=set.add("Servlet");
	System.out.println("res");
//	set.add(3,"jsp"); not available in set
	int size=set.size();
	System.out.println("total elements in set"+size);
	for(String ele:set)
		System.out.println(ele);
	TreeSet<Integer> set1=new TreeSet<>();
	set1.add(44);
	set1.add(55);
	for(int num:set1)
	{
		System.out.println(num);
	}
	TreeSet<Person> set2=new TreeSet();//by default ascending and not duplicate
	Person p1=new Person("renuka",21,"83735ADH");
	Person p2=new Person("garima",22,"83835ADH");
	Person p3=new Person("gaba",23,"83835ADT");
	Person p4=new Person("priyanka",23,"83035ADT");
	Person arr[]=new Person[4];
	arr[0]=new p1;
	arr[1]=new p2;
	Arrays.sort(arr,(new CompImp1));
	for(Person person:arr)
	{
		System.out.println(person);
	}
//	set2.add(p1);
//	set2.add(p2);
//	set2.add(p3);
//	set2.add(p4);
//	for(Person per  : set2)
//	{
//		System.out.println(per);
//	}
}
}
