
import java.util.*;
public class Main {
public static void main(String[] args) {
	//Account acc1=new Account(34621,"renuka", 2300,8.6,"saving");
	
	//acc1.printAccountDetails();
	//Account.changeInterestRate(5.8);
	/*Account acc1=new Account(34621,"renuka", 2300,8.6,"saving");
	acc1.deposit(330000);
	System.out.println(acc1);*/
	Scanner sc=new Scanner(System.in);
	System.out.println("enter first name");
	String name =sc.next();
	System.out.println("enter account number");
	int accno=sc.nextInt();
	System.out.println("enter balance");
	double balance=sc.nextDouble();
	System.out.println(name+ ":" +accno+":"+balance);
	sc.close();
	/*long old=System.currentTimeMillis();
	for(int i=1;i<=900000;i++)
	{
	long New=System.currentTimeMillis();
	System.out.println("time for execution"+(New-old));

	}*/
	
	
}
}
