import java.util.Arrays;
public class VarArgsDemo {
//public static void add(int...arr)
//{   int sum=0;
//    for(int num:arr)
//	{sum=sum+num;}
//
//System.out.println(sum);
//}
//public static void main(String[] args) {
//	add(20,23);
//	add(4,6);
//}
	public static void main(String[] args) 
{
	int[] arr={3,56,54,76,4,34,89};
      Arrays.sort(arr);
    System.out.println("After Sorting");
    for(int num:arr)
	System.out.println(num);
    int num=Arrays.binarySearch(arr, 76);
    System.out.println("76 is at"+num);
}
}

