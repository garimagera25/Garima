import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;


public class DemoAutoBoxing {
  public static void main(String[] args) {
//	int num=465;
//	Integer intObj=new Integer(num);//explicitly primitive to object type
//	Integer obj2=Integer.valueOf(num);//explicitly primitive to object type
//	Integer obj3=num;
   ArrayList<Integer> list=new ArrayList();
	Vector<Integer> list1=new Vector<>();
//	list.add(num);
//	int num2=obj3;
//	System.out.println(num2);
//	Integer obj1=new Integer(567);
	
	list.add(546);
	list.add(6598);
	list.add(433);
	int ele4=list1.firstElement();
	int ele3=list1.lastElement();
	int ele2=list1;
	list1.add(4,56);//at 4th index add 56
   
    
	int size=list.size();
	System.out.println("Total elements in list"+size);
	System.out.println("list elements are");
	//for each loop
	for(int ele:list)
	{	System.out.println("by for each");
		System.out.println(ele);
		ele++;
	}
	//simple for  loop
	for(int i=0;i<size;i++)
	{
		int ele=list.get(i);
		System.out.println("simple loop");
		System.out.println(ele);
	}
	//using iterator
	Iterator<Integer> itr=list.iterator();
	System.out.println("using iterator");
	while(itr.hasNext())
	{
		int ele=itr.next();
		System.out.println(ele);
		if(ele%10==0)
			itr.remove();
		
	
	System.out.println("after changes");
	System.out.println(ele);
	}
}
}
