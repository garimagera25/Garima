
public class AgeCompImp1 implements Comparator<Person>{
public int compare(Person person1.Person person2)
{ if()
	}
}
