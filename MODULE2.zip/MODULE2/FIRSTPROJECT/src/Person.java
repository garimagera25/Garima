
public class Person implements Comparable<Person>{
private String name;
private int age;
private String adhaarno;
public Person(String name,int age,String ano)
{
	this.name=name;
	this.age=age;
	this.adhaarno=ano;}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getAdhaarno() {
	return adhaarno;
}
public void setAdhaarno(String adhaarno) {
	this.adhaarno = adhaarno;
}
public String toString()
{
	return name+""+age+""+adhaarno;
}
@Override
public int compareTo(Person person)
{
	return this.name.compareTo(person.getName());}



}