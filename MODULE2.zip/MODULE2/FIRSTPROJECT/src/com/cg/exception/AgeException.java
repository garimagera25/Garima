package com.cg.exception;

public class AgeException extends Exception {

	private int age;
	public AgeException(int age)
	{
		this.age=age;
	}
	public void printError()
	{
		System.out.println("is invalid age");
	}
}
