package com.cg.exception;

import java.util.Scanner;

public class Exceptiondemo {
//	public static void divide(int num1,int num2)
//	{   try{
//		
//	if(num2==0)
//		throw new ArithmeticException("division by 0 error");
//		double res=(double)num1/num2;
//	    System.out.println(res);
//	}
//	catch( ArithmeticException e)
//	{
//		System.out.println(e.getMessage());
//	}
//	finally
//	{
//		System.out.println("inside finally block");
//	}
//	}
//	
public static void main(String[] args) {
//	String str=null;
//	char ch=str.charAt(4);
//	System.out.println(ch);
//	Scanner sc=new Scanner(System.in);
//	System.out.println("enter two numbers");
//	int num1=sc.nextInt();
//	int num2=sc.nextInt();
//	divide(num1,num2);
//	sc.close();
	try(Scanner sc=new Scanner(System.in);)
	{
		System.out.println("ener two nos");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		double res=num1/num2;
		System.out.println(res);
		
	}
	catch(ArithmeticException e)
	{System.out.println(e.getMessage());}
	
}
}
