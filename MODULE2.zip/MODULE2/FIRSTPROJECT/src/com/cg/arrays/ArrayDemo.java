package com.cg.arrays;
public class ArrayDemo {
public static void main(String[] args) {
//	String sarr[]={"Hello","Java","Arrays"};
//	for(String str:sarr)
//		System.out.println(str);
	Personp[] person=new Personp[5];
	person[0]=new Personp("neha",25);
	person[1]=new Personp("priya",5);
	person[2]=new Personp("nea",2);
	person[3]=new Personp("na",29);
	person[4]=new Personp("nyua",98);
	for(Personp persona:person)
	{
		System.out.println(persona.getName()+""+persona.getAge());
		}
}
}
