package com.cg.arrays;
public class Personp {
 String name;
 float Age;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getAge() {
	return Age;
}
public void setAge(float age) {
	Age = age;
}
public Personp(String name,int age)
{
	super();
	this.name=name;
	this.Age=age;
}
}
