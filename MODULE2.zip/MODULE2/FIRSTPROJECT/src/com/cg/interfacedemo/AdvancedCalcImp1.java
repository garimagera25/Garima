package com.cg.interfacedemo;

public class AdvancedCalcImp1 {

}
