package com.cg.interfacedemo;

public class Main {
public static void main(String[] args) {
	//Calculator calc=new CalcImp1();
	Calculator calc=new CalcImp1();
	int num=calc.add(23,34);
	System.out.println("addition" +num);
	int res=calc.subtract(45,7);
	System.out.println("subtraction:" +res);

	
}
}
