package com.cg.inheritance;
public abstract class DemoAbsShape {
 String name;
 
 DemoAbsShape()
 {
	 name=""
 }
}
