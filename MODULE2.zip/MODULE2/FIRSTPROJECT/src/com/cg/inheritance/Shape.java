package com.cg.inheritance;
public class Shape
{
	
	Shape()
	{
		
		System.out.println("shape clas constructor");
	}
   public void draw()
   {
	   System.out.println("we can draw");
	}
}
