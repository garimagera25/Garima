package com.cg.inheritance;

public class Rectangle extends Shape {
	int length,breadth;
	int area;
	Rectangle(int l,int b)
	{
		length=l;
		breadth=b;
	}
   public void draw()
   {
	   System.out.println("In rectangle class");
   }
   public void calArea()
   {
	   area=length*breadth;
	   System.out.println("area="+area);
   }
}
