package com.cg.inheritance;

public class DemoAbsShapeMain {
public static void main(String[] args) {
	DemoAbsShape Shape=
}
}
