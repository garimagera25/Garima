package com.cg.inheritance;
public class Circle extends Shape
{
 
	double radius;
	double area;
	
	/*public void draw()
	{
		System.out.println("draw the circle" );
	}*/
		
	public void calArea()
	{	
		area=Math.PI*radius*radius;
		//super.draw();
		System.out.println("area of circle"+area);
	 }

	Circle()
	{
		
		System.out.println("default cons circle");
		
	}
	Circle(double radius)
	{
		super();//to call explicitly constructor of shape class
		this.radius=radius;
	}
	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}
}
