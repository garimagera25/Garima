package com.cg.inheritance;
public class ShapeMain {
public static void main(String[] args) {
//	Circle circle=new Circle();
//	circle.setRadius(5);
//	circle.calArea();
//	circle.draw();
//	Shape shape=new Circle();
//	shape.draw();
//	((Circle)shape).setRadius(6);
//	((Circle)shape).calArea();
	Shape shape=new Rectangle(5,3);
	shape.draw();
}
}
