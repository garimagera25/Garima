package com.cg.regex;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
public class RegexDemo {
public static void main(String[] args) {
//	String str="11:32:43:74"; 
//	String str2="hello,How are You?";
//	String nums[]=str.split(":");
//	for(int i=0;i<nums.length;i++)
//	
//		System.out.println(nums[i]);
//
//	str2=str2.replaceAll("[A-Z]","regex");
//	
//	System.out.println(str2);
//	
//	Pattern pattern=Pattern.compile("^[A-Z][a-z]*$");//input validation +$ for one or more or {5}
//	Scanner sc=new Scanner(System.in);
//	System.out.println("enter your name");
//	String str3=sc.next();
//	Matcher matcher=pattern.matcher(str3);
//	boolean res= matcher.matches();
//	if(res)
//		System.out.println("name is valid" );
//	else System.out.println("invalid name");
//	sc.close();
	Scanner sc1=new Scanner(System.in);
	System.out.println("enter mobile number");
	String str4=sc1.next();
	boolean res1=Pattern.matches("[0-9]{10}", str4);//or "[0-9]{3}-[0-9]{3}-[0-9]{4}"
	if(res1)
	{
		System.out.println("valid number");
		
	}
	else
		System.out.println("invalid number");
	sc1.close();
	//date validation dd/MM/yyyy
	
	
}
}
