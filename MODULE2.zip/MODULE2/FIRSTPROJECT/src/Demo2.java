import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
public class Demo2 {
public static void main(String[] args) {
	HashMap<Integer,Double> map=new HashMap<>();
	map.put(1,67.86);//pair called as entry
	map.put(2,65.86);
	map.put(3,68.86);
	map.put(4,67.06);
//	map.put(null,null);//only one null entry is allowed
	int size=map.size();
	System.out.println(size);
	
	Set<Entry<Integer,Double>> set= map.entrySet(); 
    Iterator<Entry<Integer,Double>> itr=set.iterator();
    while(itr.hasNext())
    {
    	Entry<Integer,Double> ele=itr.next();
    	int rollno=ele.getKey();
    	double percent=ele.getValue();
    	System.out.println(rollno+"  "+percent);
    }
    Set<Integer> keys=map.keySet();//to display keys only
    System.out.println(keys);
    Collection<Double> values=map.values();// display values
    System.out.println(values);
	//double percent=map.get(4);
	
}
}
