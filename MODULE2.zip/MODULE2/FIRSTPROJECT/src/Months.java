
public enum Months {
   JAN(31,"January"),FEB(28,"February"),MAR(31,"March"),APR(30,"APRIL"),MAY(31,"May"),
   JUN(30,"JUNE"),JUL(31,"July"),AUG(30,"August");
   
   
   int days;
   String name;
   Months(int days, String name)
   {
	   this.days=days;
	   this.name=name;
   }
   public void display()
   {
	   System.out.println(days);
	   System.out.println(name);
	   
   }
}
