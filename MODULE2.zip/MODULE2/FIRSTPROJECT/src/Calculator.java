import java.util.ArrayList;


public class Calculator {
//public void add(T num1,T num2)
//{
//	System.out.println(num1+":"+num2);
//	}
//public static void main(String[] args) {
//	Calculator<Double> cal=new Calculator<>();
//	cal.add(34.55, 63.86);//any datatype object
public static void printgetMaxNumber(ArrayList< ? super Number > list)//Number
{
	}
	public static void main(String[] args) {
//		ArrayList list=new ArrayList();
//		list.add(46); this vl be a problem bcoz we cant add float to int
		
		ArrayList<Integer> list1=new ArrayList<>();
		ArrayList<Object> list2=new ArrayList<>();
		ArrayList<Double> list3=new ArrayList<>();
		ArrayList<String> list4=new ArrayList<>();
		ArrayList<Number> list5=new ArrayList<>();
	//	printgetMaxNumber(list1);//doesnt come in super class of number
		printgetMaxNumber(list2);
	//	printgetMaxNumber(list3);//doesnt come in super class of number
	//	printgetMaxNumber(list4);//doesnt come in super class of number
		list5.add(47);
		list5.add(56.43);
		 printgetMaxNumber(list5);
		
	}
	 

}
