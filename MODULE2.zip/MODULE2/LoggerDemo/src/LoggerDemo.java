import com.cg.logger.demo.Calculator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class LoggerDemo {
public static void main(String[] args) {
	PropertyConfigurator.configure("resources/log4j.properties");
	Calculator cal=new Calculator();
	Logger logger=Logger.getLogger(LoggerDemo.class);
	System.out.println("please see the basic.log file for long messages");
	int address=cal.add(46, 74);
	int subres=cal.sub(34, 23);
	double divres=cal.divide(78, 12);
	int mulres=cal.multiply(3, 4);
	logger.info("Addition result"+address);
	logger.info("subtraction  result"+subres);
	logger.info("division result"+divres);
	logger.info("multiplication result"+mulres);

	
	
	
	logger.debug("this is debug level msg");
	logger.info("this is info level msg");
	logger.warn("this is warn level msg");
	logger.error("this is error level msg");
	logger.fatal("this is fatal level msg");


}
	
}
