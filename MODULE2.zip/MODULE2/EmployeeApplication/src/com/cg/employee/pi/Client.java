package com.cg.employee.pi;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import com.cg.employee.dto.Department;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.DepartmentService;
import com.cg.employee.service.DepartmentServiceImpl;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;
import com.cg.employee.service.ValidateService;
import com.cg.employee.service.ValidateServiceImpl;







public class Client {
	public static void main(String[] args) {
		
	

	Employee employee= new Employee();
	EmployeeService service= new EmployeeServiceImpl();
	Department department= new Department();
	ValidateService validation=new ValidateServiceImpl();

	Scanner sc= new Scanner(System.in);
	int option=0;
	do{
	System.out.println("\n1. Display Employee Details ...");
	System.out.println("2. Display Employee List ...");
	System.out.println("3. Update employee salary ...");
   System.out.println("4. Delete employee details");
	System.out.println("5. add employee details ");
	System.out.println("6. Exit");
	System.out.println("Enter Choice .");
	 option= sc.nextInt();
	 switch(option){
		case 1 :System.out.println("enter employee id");
		int id =sc.nextInt();
	
		try
		{
			 employee= service.getEmployeeDetails(id);
		
		System.out.println(employee.getFname()+""+employee.getLname()+""+employee.getGender()+""+employee.getMailid()
				            +""+employee.getDeptid()+""+employee.getMobileno()+""+employee.getSalary());
	} catch (EmployeeException e) {
		
		System.out.println(e.getMessage());
	}	
		break;
	
		case 2:
		     	System.out.println("enter department number");
	          int deptid =sc.nextInt();
	         department.setDeptno(deptid);
	        try
	        {
	        	DepartmentService dservice= new DepartmentServiceImpl();
	    	  List<Department> depart=dservice.getEmployeeList(deptid);
	    	  if(depart.size()>0)
	    	  {  for(Department dep:depart)
	    		  {
	    		  System.out.print(dep.getEname());
	    			  }
	    		  }
	      else
				System.out.println("No employee records available");
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
			
		}
	        break;
		case 3: System.out.println("enter employee id");
        int empid =sc.nextInt();
       employee.setEmpid(empid);
       System.out.println("Enter salary ");
		int sal= sc.nextInt();
		
		employee.setEmpid(empid);
		employee.setSalary(sal);
		
		try {
			double rev= service.updateEmployee(employee);
			if(rev==1)
				{
				System.out.println("salary updated successfully ");
				}
			else
				{
				System.out.println("id not available");
				}
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}				
		break;
		case 4:
			System.out.println("Enter employee id ");
			int emid= sc.nextInt();
			try {
				int rv= service.deleteEmployee(emid);
				if(rv==1)
					{
					System.out.println("employee details deleted .");
					}
				else
					
					System.out.println("Mobile does not exist");
			} catch (EmployeeException e) {
				System.out.println(e.getMessage());
			}break;
		
		case 5:
			do{System.out.println("Enter employee first name : ");

			String fname =sc.next();
			
			boolean res=validation.validateFname(fname);
			if(res==true)
			{
				employee.setFname(fname);
				break;
			}
			else
				
				System.out.println("Name should contain only alphabets");
			}while(true);
			
			do{
			System.out.println("Enter employee last name : ");

			String lname =sc.next();
			
			boolean res=validation.validateLname(lname);
			if(res==true)
			{
				employee.setFname(lname);
				break;
			}
			else
				
				System.out.println("Name should contain only alphabets");
			}while(true);
			do{
				System.out.println("Enter gender : ");
				String gender= sc.next();
				boolean res=validation.validateGender(gender);
				if(res==true)
				{	
				
				employee.setGender(gender);
				break;
			}
				else
					System.out.println("gender is not valid");
			}while(true);
			
			do{
			System.out.println("Enter Mail id : ");
			String mailid= sc.next();
			boolean res= validation.validateMailId(mailid);
			if(res==true)
				{
					employee.setMailid(mailid);
					break;
				}
				else
					System.out.println("Mail id as: abcd@capgemini.com ");
			}while(true);
			do{
				System.out.println("Enter mobile No :");
				String mobno= sc.next();
				boolean res=validation.validateMnumber(mobno);
				if(res==true)
				{
					employee.setMobileno(mobno);
					break;
				}
				else
					System.out.println("Mobile no shoule be 10 digit.");
			}while(true);
			
				
				
			do{
			LocalDate jd;
			try {
				System.out.println("Enter Date of joining (dd/MM/yyyy) : ");
				String date= sc.next();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				jd = LocalDate.parse(date, formatter);
				employee.setJoiningDate(jd);
				break;
				
			} catch (Exception e) {
				System.out.println("Invalid date entered..");
			}
			}while(true);
			
			   System.out.println("enter department id");
			    int deptno=sc.nextInt();

			    employee.setDeptid(deptno);
			

			System.out.println("Enter salary : ");
			double salary= sc.nextDouble();
			 employee.setSalary(salary);
			 
			    try
			    {
			    int empid1= service.addEmployee(employee);
				System.out.println("Employee added : "+ empid1 );
			    } 
			    catch (EmployeeException e) {
			    System.out.println(e.getMessage());
			    }	
			    break;
	
	case 6:		
		break;
	    	
		default:System.out.println("please enter correct option ");
	
	}//switch
	}while(option!=6);
	 // end of do while 
	}// end of main method

}// end of class

		


	