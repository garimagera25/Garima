package com.cg.employee.dao;


import java.util.List;

import com.cg.employee.dto.Department;

import com.cg.employee.exception.EmployeeException;

public interface DepartmentDao {
	public List<Department> getEmployeeList(int deptno) throws EmployeeException ;
}
