package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DatabaseConnection;




public class EmployeeDaoImpl implements EmployeeDao {
	

		
		Connection connection;
		public EmployeeDaoImpl() {
			connection= DatabaseConnection.getConnection();
		}
		protected void finalize(){
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	

	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		String insQry=
				"INSERT INTO employee (fname, lname,gender ,mailid,mobileno,joiningdate,salary,empid,deptid) values (?,?,?,?,?,?,?,em_id_seq.nextval,?) ";
				try {
					PreparedStatement ps = connection.prepareStatement(insQry);
					
					ps.setString(1, employee.getFname());
					ps.setString(2,employee.getLname());
					ps.setString(3, employee.getGender());
					ps.setString(4,employee.getMailid());
                     
					
					
					ps.setString(5,employee.getMobileno());
				    Date date=Date.valueOf(employee.getJoiningDate());
					ps.setDate(6,date);
					ps.setDouble(7, employee.getSalary());
					ps.setInt(8, employee.getDeptid());
					
					
					int r= ps.executeUpdate();
					int empid=0;
					if(r==1){
							Statement st= connection.createStatement();
							ResultSet rs= st.executeQuery("select em_id_seq.currval from dual");
							if(rs.next())
								empid=rs.getInt(1);
					}
				return empid;
				} catch (SQLException e) {
					throw new EmployeeException(e.getMessage());
				}
		
	}


//	public List<Employee> getEmployeeList(int deptno) throws EmployeeException {
//		String selQry= "select fname, name from department where deptno=? ";
//		List<Employee> employeelist= new ArrayList<Employee>();
//		try {
//			PreparedStatement ps= connection.prepareStatement(selQry);
//			ResultSet rs= ps.executeQuery();
//			
//			while( rs.next()){
//				Employee emp= new Employee ();
//				emp.setFname(rs.getString(1));
//				emp.setLname(rs.getString(2));
//				employeelist.add(emp);
//			}			
//		} catch (SQLException e) {
//			throw new EmployeeException(e.getMessage());
//		}		
//		return employeelist;
//		
//	}

	@Override
	public Employee getEmployeeDetails(int id) throws EmployeeException {
		// TODO Auto-generated method stub

		Employee employee= new Employee();
		String selQry= "select fname, lname,gender ,mailid,mobileno,salary,empid,deptid from employee where empid=? ";
		try {
			PreparedStatement ps= connection.prepareStatement(selQry);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				employee.setFname(rs.getString(1));
				employee.setLname(rs.getString(2));
				employee.setMailid(rs.getString(3));
				employee.setGender(rs.getString(6));
				employee.setMobileno(rs.getString(4));
//				Date date=Date.valueOf(employee.getJoiningDate());
//				employee.setJoiningDate(joiningDate);
				employee.setSalary(rs.getDouble(7));
				employee.setDeptid(rs.getInt(5));
				
			
				
				
				
			}
			else 
			throw new EmployeeException("employee id does not exist");
			
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		return employee;
		
	}

	@Override
	public double updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		String updateQry= "update employee set salary=? where empid=?";
		try {
			PreparedStatement ps= connection.prepareStatement(updateQry);
			ps.setDouble(1, emp.getSalary());
			ps.setInt(2, emp.getEmpid());
			int rs= ps.executeUpdate();
			return rs;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	
	}
		
	

	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		String deleteQry= "delete from  employee where empid=?";
		try {
			PreparedStatement ps= connection.prepareStatement(deleteQry);
			ps.setInt(1, id);
			int rs= ps.executeUpdate();
			return rs;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	
		
	}
	}
