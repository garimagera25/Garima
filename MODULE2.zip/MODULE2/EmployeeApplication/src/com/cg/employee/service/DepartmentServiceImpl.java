package com.cg.employee.service;



import java.util.List;

import com.cg.employee.dao.DepartmentDao;
import com.cg.employee.dao.DepartmentDaoImpl;
import com.cg.employee.dto.Department;
import com.cg.employee.exception.EmployeeException;


public class DepartmentServiceImpl implements DepartmentService {
	DepartmentDao dao;
	public DepartmentServiceImpl() {
		dao= new DepartmentDaoImpl();
		
}
	@Override
	public List<Department> getEmployeeList(int deptno)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeList(deptno);
	
	}
}
