package com.cg.employee.service;



import java.util.List;

import com.cg.employee.dto.Department;
import com.cg.employee.exception.EmployeeException;

public interface DepartmentService {
	public List<Department> getEmployeeList(int deptno) throws EmployeeException ;
}
