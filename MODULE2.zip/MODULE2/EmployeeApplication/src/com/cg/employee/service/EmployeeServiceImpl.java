package com.cg.employee.service;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;


public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao dao;
	public EmployeeServiceImpl(){
		dao= new EmployeeDaoImpl();
		}
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		int id = dao.addEmployee(employee);
		return id;
		
	}

	@Override
	public Employee getEmployeeDetails(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getEmployeeDetails(id);
		
	}

	@Override
	public double updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(emp);
		
	}

	@Override
	public int deleteEmployee(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(id);
		
	}

}
