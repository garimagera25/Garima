package com.cg.employee.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidateServiceImpl implements ValidateService{

	

	@Override
	public boolean validateMailId(String mailid) {
		Pattern pattern= Pattern.compile("[A-Za-z0-9]*@capgemini.com");
		Matcher matcher= pattern.matcher(mailid);
		return matcher.matches();
	}

	

	

	@Override
	public boolean validateFname(String fname) {
		// TODO Auto-generated method stub

		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(fname);
		return matcher.matches();
		
	}

	@Override
	public boolean validateLname(String lname) {
		// TODO Auto-generated method stub

		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(lname);
		return matcher.matches();
		
		
	}

	@Override
	public boolean validateGender(String gender) {
		// TODO Auto-generated method stub
		Pattern pattern=Pattern.compile("[f,F,m,M]");
		Matcher matcher=pattern.matcher(gender);
		
		return matcher.matches();
	}

	@Override
	public boolean validateMnumber(String number) {
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher matcher= pattern.matcher(number);
		return matcher.matches();
		
	}

	

}
