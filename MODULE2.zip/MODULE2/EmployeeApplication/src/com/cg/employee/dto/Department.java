package com.cg.employee.dto;



public class Department {
private String ename;

private int deptid;

public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}

public int getDeptno() {
	return deptid;
}
public void setDeptno(int deptid) {
	this.deptid = deptid;
}

}

