import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;


public class FileWriteDemo {
public static void main(String[] args) {
	
	try {
		FileOutputStream fos=new FileOutputStream("Demo.txt");
		char ch=0;
		System.out.println("enter data  to write into file,# to terminate");
		while(ch!='#')
		{
			ch=(char)System.in.read();
			fos.write(ch);
		}
		fos.close();
		System.out.println("data written to file");
	} catch (FileNotFoundException e)
	{
		e.printStackTrace();
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
