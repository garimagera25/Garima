package com.cg.files.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadObjects {
public static void main(String[] args) {
	try
	{
	FileInputStream fin=new 	FileInputStream("PersonDetails.dat");
	ObjectInputStream ois=new ObjectInputStream(fin);
	for(int i=0;i<=3;i++)
	{	
	Person p1=(Person)ois.readObject();
	System.out.println("name"+p1.getName());
	System.out.println("age"+p1.getAge());
	System.out.println("gender"+p1.getGender());
	}
	ois.close();
	}
	catch(FileNotFoundException e)
	{
		e.printStackTrace();
		
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	
}
}
