import java.io.File;
import java.util.Date;


public class FileOperations {
public static void main(String[] args) {
	File file=new File("Demo1.txt");
	boolean res=file.createNewFile();
	if(res)
		System.out.println("file created");
		System.out.println("");
	System.out.println("is it a file?"+file.isFile());
	System.out.println("is it a directory"+file.isDirectory());
	System.out.println("Path:"+file.getAbsolutePath());
	Date date=new Date(file.lastModified());
	System.out.println("last modified date"+date);
	//file.setReadOnly();
//	boolean res=file.setReadOnly();
//	if(res)
//		System.out.println("now the file is read only");
	file.setWritable(true);
	
	
}
}
