import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;


public class BufferDemo {
public static void main(String[] args) {
	try
	{
		FileReader fr=new FileReader("Demo.txt");
		BufferedReader br= new BufferedReader(fr);
		LineNumberReader lr=new LineNumberReader(br);
		String line="";
		while(line!=null)
		{
			line=lr.readLine();
			System.out.println(lr.getLineNumber()+""+line);
		}
		lr.close();
		
	}catch (FileNotFoundException e)
	{
		e.printStackTrace();
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
