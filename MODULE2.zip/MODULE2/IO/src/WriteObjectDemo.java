import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.cg.files.demo.Person;

public class WriteObjectDemo {
public static void main(String[] args) {
	Person p1=new Person("smith","male",43);
	Person p2=new Person("kathy","male",47);
	Person p3=new Person("sammy","male",43);
	try
	{
	FileOutputStream fos=new FileOutputStream("PersonDetails.dat");
	ObjectOutputStream oos=new ObjectOutputStream(fos);
	oos.writeObject(p1);
	oos.writeObject(p2);
    oos.writeObject(p3);
    System.out.println("person objects written into file");
    oos.close();
	}catch(FileNotFoundException e)
	{
		
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
	
}
}
