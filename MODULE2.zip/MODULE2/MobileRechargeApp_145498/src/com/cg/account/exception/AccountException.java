package com.cg.account.exception;

public class AccountException extends Exception {
	public AccountException(String msg) {
		super(msg);
	}
}
