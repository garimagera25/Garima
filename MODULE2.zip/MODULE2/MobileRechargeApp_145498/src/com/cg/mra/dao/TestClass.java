package com.cg.mra.dao;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.cg.account.exception.AccountException;

public class TestClass {
@Test
public void testRechargeAccount()
{  AccountDao dao=new AccountDaoImpl();
  try{
	 int list= dao.rechargeAccount("101", 10);
	 Assert.assertTrue(list!=0);
  }catch(AccountException e)
  {
	  e.printStackTrace();
	  
  }
     
	}

}
