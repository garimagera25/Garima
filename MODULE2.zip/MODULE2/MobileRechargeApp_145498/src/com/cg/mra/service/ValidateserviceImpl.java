package com.cg.mra.service;

public class ValidateserviceImpl implements ValidateService{

}
