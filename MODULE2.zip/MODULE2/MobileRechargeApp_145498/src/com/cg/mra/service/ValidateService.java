package com.cg.mra.service;

public interface ValidateService {

}
