package com.cg.mra.service;

import com.cg.account.exception.AccountException;
import com.cg.mra.beans.Account;

public interface AccountService {
  Account getAccountDetails(String accountId) throws AccountException;
  int rechargeAccount(String accountId,double rechargeAmount)throws AccountException;
}
