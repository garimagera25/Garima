package com.cg.mra.ul;
import org.apache.log4j.Logger;


import java.util.Scanner;


import org.apache.log4j.PropertyConfigurator;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.account.exception.*;
public class Client {
public static void main(String[] args) {
	PropertyConfigurator.configure("resources/log4j.properties");
	Account account= new Account();
	AccountService service= new AccountServiceImpl();
	Logger logger=Logger.getLogger(Client.class);
	//
	Scanner sc= new Scanner(System.in);
	int option=0;
	do{
	System.out.println("\n\n1. Display balance ...");
	System.out.println("2. Update balance ...");
	System.out.println("3. exit  ...");
	System.out.println("Enter Choice .");
	 option= sc.nextInt();
	switch(option){
	case 1 :System.out.println("Enter account id :  ");
	String id= sc.next();
	try {
		account =service.getAccountDetails(id);
      
		
		System.out.println("Your account id "+account.getAccountId()+"is having balance "+ account.getAccountbalance());
		logger.info("Your account id "+account.getAccountId()+"is having balance "+ account.getAccountbalance() );
	
	} catch (AccountException e) {
		
		System.out.println(e.getMessage());
		logger.error(e.getMessage());
	}break;
	case 2:System.out.println("enter recharge amount");
	       logger.info("enter recharge amount");
	     double rech=sc.nextDouble();
	
		System.out.println("Enter account id :  ");
		logger.info("Enter account id :  ");
		String aid= sc.next();
		account.setAccountbalance(rech);
		account.setAccountId(aid);
		try{
			int rev=service.rechargeAccount(aid,rech);
			if(rev==1)
			{	System.out.println("recharge updated successfully");
			    logger.info("recharge updated successfully");
			}
			else
			{	System.out.println("failed");
			    logger.info("failed");
			}
			
		}catch(AccountException e)
		{
			System.out.println(e.getMessage());
			logger.error(e.getMessage());
		}
	case 3:System.out.println("process terminated");
	       logger.info("process terminated");
		break;
	default:System.out.println("wrong choice");
	        logger.info("wrong choice");
			}//end of swich statement
	
	}while(option!=4);//end of while statement
	sc.close();
}//end of main method
	
}//end of class client

