
final class queston19 {
String name;
int rooms;
//queston19(){}
 queston19(){}
}
