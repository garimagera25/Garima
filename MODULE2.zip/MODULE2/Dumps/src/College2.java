class Phone1
{
	String keyboard="in built";
	}
class Tablet extends Phone1
{
	String sc="adjfh";
	boolean playMovie=false;
	}
public class College2 {
public static void main(String[] args) {
	Phone1 Phone1=new Tablet();
	System.out.println(Phone1.keyboard+""+Phone1.playMovie+""+Phone1.sc);
//cant access subclass varibles
}
}
