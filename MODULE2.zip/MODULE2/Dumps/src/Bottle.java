
public class Bottle {
	void Bottle(){}
	void Bottle(WaterBottle w){}

}
class WaterBottle extends Bottle
{
	}
