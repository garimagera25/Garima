
public class question20 {
int[] eArr1={10,20,30};
int[] eArr11=new int[10];
int[] eArr111=new int[10];//cant use paranthesis {} with [];
int[] eArr1111=new int[]{};//can use paranthesis with empty[]
int[] eArr11111=new int[]{10,20};//can intialize array with empty subscript 
}
