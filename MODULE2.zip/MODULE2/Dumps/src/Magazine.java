class Book1{
	/*private*/ int pages=100;
}
public class Magazine extends Book1 {
	private int interviews=2;
	private int totalPage(){
		
	return super.pages+interviews*5;	
	}
	public static void main(String[] args) {
		System.out.println(new Magazine().totalPage());
	}
	
//a subclass cannot access private  variables and methods of super class
}
