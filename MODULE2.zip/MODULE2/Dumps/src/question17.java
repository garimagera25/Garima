


public class question17 {
void question()
{
	try{
		question();
		System.out.println("question");
	}
	catch(StackOverflowError e){
		System.out.println("caught");
		
	}
	
	}
public static void main(String[] args) {
	new question17().question();
}
}
