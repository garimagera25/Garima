class Phone
{
	void call()
	{
		System.out.println("call phone");
	}}
class SmartPhone extends Phone{
	void call()
	{
		System.out.println("call smartphone");
	}
}
public class TestPhone {
public static void main(String[] args) {
	Phone p=new Phone();
	Phone smartPhone=new SmartPhone();
	p.call();
	smartPhone.call();
}
}
