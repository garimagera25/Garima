
public class EMyMethods {
static String name="m1";
void riverRafting()
{
	String name="m2";
	if(8>2)
	{
		String name="m3";
	}

}
}
