
public class Casting {
public static void main(String[] args) {
	Byte b1=100;
	Integer i=200;
	Long l1=(long) 300;
	Float f1=(float) (b1+l1);
	String sb=300;
	if(sb==(b1+i))
		sb=500;
	
}
}
