interface Jump{}
public class ques14 implements Jump {
public static void main(String[] args) {
	Jump ejump1[]={null,new ques14()};
//	Jump ejump2[]=new ques14()[22];
	Jump ejump3[]=new Jump[10];
	Jump ejump4[]=new ques14[87];
	//Jump ejump5[]=new Jump()[12];
}
}
