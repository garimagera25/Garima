class Person1{}
class Father extends Person1{
	public void dance() throws ClassCastException{}
}
public class Home {
	public static void main(String[] args) {
		Person1 p=new Person1();
		try{
			((Father) p).dance();
	}
		catch(ClassCastException e)
		{
			System.out.println("class cast");
		}
		catch(NullPointerException e)
		{
			System.out.println("NullPointerException");
		}
//		catch(Exception e)
//		{
//			System.out.println("Exception");
//		}
//		catch(Throwable t)
//		{
//			System.out.println("Throwable cast");
//		}
	//	finally{}

	
}
}
