package com.cg.dumps;

public class SumTest {
public static void Sum(int x,int y)
{
	System.out.println("sum="+(x+y));}
public static void Sum(double x,double y)
{
	System.out.println("double sum="+(x+y));}
public static void Sum(float x,float y)
{
	System.out.println("float sum="+(x+y));}
public static void main(String[] args) {
	Sum(10,20);
	Sum(10.0f,20.0f);
}
}

