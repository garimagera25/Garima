package com.cg.dumps;

public class App {
public static void main(String[] args) {
	String str1="Java";
	String str2=new String("java");
	//if(str1.equalsIgnoreCase(str2))
//	String str3=str2;
//	if(str1.equals(str3))
//	String str3=str2;
//	if(str1==str3)
	if(str1.toLowerCase()==str2.toLowerCase())
	{
		System.out.println("Equal");
	}else{
		System.out.println("Not Equal");
	}
}
}
