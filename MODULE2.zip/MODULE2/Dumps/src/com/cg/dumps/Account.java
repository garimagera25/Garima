package com.cg.dumps;

public class Account {
public static String maskCC(String creditCard){
	String x="XXXX-XXXX-XXXX-";
//	StringBuilder sb=new StringBuilder(creditCard);
//	sb.substring(15,19);
//	return x+sb;
//	or
//	StringBuilder sb=new StringBuilder(x);
//	sb.append(creditCard,15,19);
//	return sb.toString();
//	or
return x+creditCard.substring(15,19);
//	or
//	StringBuilder sb=new StringBuilder(creditCard);
//	StringBuilder s=sb.insert(0,x);
//	return s.toString();
}
public static void main(String[] args) {
	System.out.println(maskCC("1234-5678-9101-1121"));
	
	
}
}
