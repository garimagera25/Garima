package com.cg.dumps;
class Phone {
	void call()
	{
		System.out.println("call-phone");}
	class SmartPhone extends Phone{
		void call()
		{
			System.out.println("call-smartphone");
		}
	}
public  class TestPhone {
	public  void main(String[] args) {
			Phone phn=new Phone();
			Phone smartPhone=new SmartPhone();
			phn.call();
			smartPhone.call();
		}}
	}


