package com.cg.dumps;



public class Test3 {
public static void main(String[] args) {
	String[] planets={"Mercury","Venus","Earth","Mars"};
System.out.println(planets.length);
System.out.println(planets[1].length());
}
}