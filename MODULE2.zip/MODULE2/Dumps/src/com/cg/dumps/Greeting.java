package com.cg.dumps;

public class Greeting {
public static void main(String[] args) {
	System.out.println("Hello"+args[0]);
	
}
}
