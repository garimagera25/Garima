package com.cg.dumps;




	class A{
		public A()
		{
			System.out.println("A");
		}
	}
	class B extends A{
		public B()
		{
			System.out.println("B");
		}
	  class C extends B {
	public C()
	{
		System.out.println("c");
		System.out.println("dgfjhgsshgdsjhfghdsz");
	}
	public void main(String[] args) {
		C c=new C();
		System.out.println("in main");
	}
	}
	}

