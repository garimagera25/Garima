package com.cg.dumps;

public class Test {
public static void main(String[] args) {
	int[] array = new int[2];
	
	array[0]=10;
    array[1]=20;
    System.out.println(array[0]+":"+array[1]);
}
}
