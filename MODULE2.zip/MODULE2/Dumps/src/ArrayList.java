import java.time.LocalDate;
import java.util.*;
class Person{

	
	
}
class Emp extends Person
{}
public class ArrayList {
public static void main(String[] args) {
	ArrayList<Object> list=new ArrayList();
	list.add(new String("1234"));
	list.add(new Person());
	list.add(new Emp());
	list.add(new String[]{"abcd","xyz"});
	list.add(LocalDate.now().plusDays(1));
	
}
}
