interface Readable{
	public void readBook();
public	void setBookMark();
}
abstract class Book implements Readable{


	public void readBook() {
		// TODO Auto-generated method stub
		
	}


}
abstract	class EBook extends Book{
		
		public void readBook(){}

		

//		@Override
//		public void setBookMark() {
//			// TODO Auto-generated method stub
//			
//		}


		
		
	}


