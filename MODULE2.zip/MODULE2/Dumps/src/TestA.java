class Alpha
{
	int ns;
	static int s;
	Alpha(int newv)
	{
		if(s<newv)
		{	s=newv;
		System.out.println(s);
		System.out.println(ns);
		this.ns=newv;
		}	}
	void doPrint()
	{
		System.out.println("ns="+ns+"s"+ s);
	}
	}
public class TestA {
	public static void main(String[] args) {
		Alpha ref1=new Alpha(50);
		Alpha ref2=new Alpha(125);
		Alpha ref3=new Alpha(100);
		ref1.doPrint();
		ref2.doPrint();
		ref3.doPrint();
		
	}

}
