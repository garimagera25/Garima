package com.cg.Databse;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteDemo {
	public static void main(String[] args) {
		Connection con=DatabaseConnection.getConnection();
	   String delQuery="delete from employee_masters where deptid=?";
	   PreparedStatement ps;
	   try{
		
		ps=con.prepareStatement(delQuery);
		ps.setInt(1, 3);
		int r=ps.executeUpdate();
//		LocalDate jd=LocalDate.of(2016, 12, 24);
//		ps.setDate(4, Date.valueOf(jd));
		
		
		System.out.println(r+"rows deleted");
	}
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }


	}

	 
}
