package com.cg.Databse;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class SelectDemo {
public static void main(String[] args) {
	Connection con=DatabaseConnection.getConnection();
	String selQuery="select deptid,deptname from department_masters ";
	try{
		Statement stmt=con.createStatement();
        ResultSet rs=stmt.executeQuery(selQuery);
        while(rs.next())//next checks record is there or not
        {
        	int deptid=rs.getInt(1);
        	String dname=rs.getString(2);
        	System.out.println(deptid+":"+dname);
        }
        rs.close();
        con.close();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
}

}