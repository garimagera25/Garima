package com.cg.Databse;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateDemo {
	public static void main(String[] args) {
		Connection con=DatabaseConnection.getConnection();
	   String updateQry="update employee_masters set salary=salary+salary/10 where deptid=?";
	   PreparedStatement ps;
	   try{
		   ps=con.prepareStatement(updateQry);
		   ps.setDouble(1,500);
		   ps.setInt(1, 3);
		   int r=ps.executeUpdate();
		   System.out.println(r+"rows updated");
		   
		   
	   }catch(SQLException e)
	   {
		   e.printStackTrace();
	   }
	   }
}
	
