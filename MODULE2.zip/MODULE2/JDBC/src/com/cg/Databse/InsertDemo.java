package com.cg.Databse;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class InsertDemo {
public static void main(String[] args) {
	Connection con=DatabaseConnection.getConnection();
   String insQuery="insert into employee_masters"
   		+ "(empid,empname,salary,joindate,deptid)"
		   +"values(emp_id_seq.nextval,?,?,sysdate,?)";
try{
	PreparedStatement ps=con.prepareStatement(insQuery);
//	ps.setInt(1, 105);
	ps.setString(1, "chdc");
	ps.setDouble(2, 44000);
//	LocalDate jd=LocalDate.of(2016, 12, 24);
//	ps.setDate(4, Date.valueOf(jd));
	ps.setInt(3,3);
	int r=ps.executeUpdate();
	String sql="select emp_id_seq.currval from dual";
	Statement stmt=con.createStatement();
	ResultSet rs= stmt.executeQuery(sql);
	int empid=0;
	if(rs.next())
		empid=rs.getInt(1);
	System.out.println("employee record inserted with empid:"+empid);
	
	System.out.println(r+"rows inserted");
}
   catch(SQLException e)
   {
	   e.printStackTrace();
   }


}

 
}
