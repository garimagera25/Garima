package lambda;

import java.util.stream.Stream;

public class BasicStreamDemo {
public static void main(String[] args) {
//	Stream<Integer> stream=Stream.of(34,54,23,45,332,33);
//	//stream.map((num)->{if(num%2==0)return "even";
//	long evenNumbers=stream.map((num)->{if(num%2==0)return "even";
//	else
//		return "odd";}).filter((str)->str.equalsIgnoreCase("even")).count();//.forEach((str)->System.out.println(str));
//	System.out.println(evenNumbers);//filter is ued to diplay everytime the condition is true
//	
	
	
	
	Stream<Integer> stream=Stream.of(34,54,23,45,332,33);
	//stream.filter((num)->num%2==0).forEach((num)->System.out.println(num));
    Stream<Integer> uniqueEles=stream.distinct();
    uniqueEles.forEach(System.out::println);
    stream.skip(5).forEach(System.out::println);
    
    
   int result= stream.reduce((num1,num2)->{if(num1>num2)return num1;
   else return num2;}).get();//num1+num2).get();
    System.out.println(result);
}}


