package lambda;

public class Client {
public static void main(String[] args) {
	Calculator cal=(x,y)->{return x+y;};
	int add=cal.calculate(4,8);
	System.out.println(add);
}
}
