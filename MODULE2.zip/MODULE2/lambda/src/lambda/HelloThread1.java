package lambda;

public class HelloThread1 implements Runnable {
public String name;

public HelloThread1(String name)
{this.name=name;
	
}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("in run method"+this.getName());
		for(int i=1;i<=5;i++)
		{try{
			Thread.sleep(2000);
			System.out.println(this.getName()+""+1);
			
		}catch(InterruptedException e)
		{
			e.printStackTrace();
			
			}
		}
		System.out.println(this.getName()+"will die now");
		}
	      public static void main(String[] args) {
			HelloThread th1=new HelloThread("tom");
			HelloThread th2=new HelloThread("jerry");
			th2.setPriority(10);
			th1.start();
			th2.start();
			
			for(int i=1;i<5;i++)
			{
				try{th2.join();
//					Thread.sleep(2000);
//					System.out.println("in main thread"+i);
					
				}catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			}				System.out.println("is tom alive"+th1.isAlive());
			System.out.println("is jerry alive"+th2.isAlive());
			
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	
		
	}


