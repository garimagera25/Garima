package lambda;

public interface Test {
public boolean test(int num);
}
