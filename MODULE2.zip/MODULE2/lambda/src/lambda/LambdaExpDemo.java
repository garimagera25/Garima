package lambda;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class LambdaExpDemo {
public static void main(String[] args) {
	Supplier<String> sup=()->{return "Hello";};
	String str=sup.get();
	Consumer<String> con=(S)-> { System.out.println(S);};
	con.accept(str);//shoud be displayed on console
	BiFunction<Integer, Integer, Integer> function=
			(num1,num2)->{return num1+num2;};
			int res=function.apply(3,7);
			System.out.println(res);
		Predicate<Integer> prd=(num)->{if(num%2==0) return false;
		else return true;		};
	System.out.println("5 is odd?"+prd.test(5));
}
}
