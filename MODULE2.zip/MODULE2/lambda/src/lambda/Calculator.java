package lambda;
@FunctionalInterface
public interface Calculator {
	public int calculate(int x,int y);
}


