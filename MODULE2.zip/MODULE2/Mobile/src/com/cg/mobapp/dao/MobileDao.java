package com.cg.mobapp.dao;
import java.util.List;
import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;

public interface MobileDao {
 public int addMobile(Mobile mobile)throws MobileException ;
 public Mobile getMobileDetails(int id)throws MobileException;
 public int updateMobile(Mobile mob)throws MobileException;
 public int deleteMobile(int id)throws MobileException;
 public List<Mobile> getMobileList()throws MobileException;
 
}
