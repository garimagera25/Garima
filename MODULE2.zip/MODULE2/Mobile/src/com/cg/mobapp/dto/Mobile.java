package com.cg.mobapp.dto;

public class Mobile {
	private int MobileId;
	private String MobileName;
 private double price;
 private int quantity;
public double getPrice() {
	return price;
}
public int getMobileId() {
	return MobileId;
}
public void setMobileId(int mobileId) {
	MobileId = mobileId;
}
public String getMobileName() {
	return MobileName;
}
public void setMobileName(String mobileName) {
	MobileName = mobileName;
}
public void setPrice(double price) {
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
}
