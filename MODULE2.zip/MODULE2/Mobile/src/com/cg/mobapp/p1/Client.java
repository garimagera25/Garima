package com.cg.mobapp.p1;

import java.util.List;
import java.util.Scanner;

import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.service.MobileService;
import com.cg.mobapp.service.MobileServiceImpl;

public class Client {
public static void main(String[] args) {
	Mobile mobile=new Mobile();
	MobileService service=new MobileServiceImpl();
		Scanner sc=new Scanner(System.in);
		int option;
	do{	
		System.out.println("1 add mobile details");
		System.out.println("2 display mobile list");
		System.out.println("1 display mobile ");
		System.out.println("3 exit");
		System.out.println(" enter your choice");
		 option=sc.nextInt();
		switch(option)
		
	{	
		
	case 1:
	System.out.println("enter mobile name");
	String name=sc.next();
	System.out.println("enter price");
	double price=sc.nextDouble();
	System.out.println("enter  quantity");
	int quantity=sc.nextInt();
	
	mobile.setMobileName(name);
	mobile.setPrice(price);
	mobile.setQuantity(quantity);
	
	try
	{
		int mobileid=service.addMobile(mobile);
		System.out.println("Mobile added"+mobileid);
		
	}
	catch(MobileException e)
	{
		System.out.println(e.getMessage());
	}
	break;
	case 2:
	//display all mobile details on console
	try{
		List<Mobile> mobiles=service.getMobileList();
		if(mobiles.size()>0)
		{
			for(Mobile mob:mobiles)
				System.out.println(mob.getMobileId()+""+mob.getMobileName()+""+mob.getPrice()+""+mob.getQuantity());
		}
		else
			System.out.println("no mobile records available");
		
	}catch(MobileException e)
	{
		System.out.println(e.getMessage());
	}
	break;
	case 3:
	//display mobile details
	System.out.println("enter mobile no");
    int mobileid=sc.nextInt();
    try
    {mobile=service.getMobileDetails(mobileid);
    System.out.println(mobile.getMobileId()+""+mobile.getMobileName()+""+mobile.getPrice()+""+mobile.getQuantity());
    }
    catch(MobileException e)
	{
		System.out.println(e.getMessage());
	}
	case 4: System.out.println("enter quantity ");
	        int quan=sc.nextInt();
	        System.out.println("enter mobile id");
	        int mobid=sc.nextInt();
	        mobile.setMobileId(mobid);
	        mobile.setQuantity(quan);
	        try
	        {
	        	int rv=service.updateMobile(mobile);
	        	if(rv==1)
	        	{
	        		System.out.println("quantity successfully updated");
	        		
	        	}
	        }catch(MobileException e)
	    	{
	    		System.out.println(e.getMessage());
	    	}
	        break;
	        
	case 5:
		System.out.println("enter  quantity");
		int quan=sc.nextInt();
        System.out.println("enter mobile id");
        int mobid=sc.nextInt();
        mobile.setMobileId(mobid);
        mobile.setQuantity(quan);
        try
        {
        	int rv=service.updateMobile(mobile);
        	if(rv==1)
        	{
        		System.out.println("quantity successfully updated");
        		
        	}
        }catch(MobileException e)
    	{
    		System.out.println(e.getMessage());
    	}
	}
	}while(option!=4);
	
	
}
}

