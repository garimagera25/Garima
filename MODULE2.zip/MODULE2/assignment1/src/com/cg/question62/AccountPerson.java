package com.cg.question62;

import com.cg.exception.AgeException;

public class AccountPerson{
	 int accountno;
	 Person accountHolderName;
	 double balance;
	 public static int count=1000;
	
	 
	 public int getAccountno() {
		return accountno;
	}
//	public static int getCount() {
//		return count;
//	}
//	public static void setCount(int count) {
//		AccountPerson.count = count;
//	}
	public AccountPerson()
	{count++;
	  accountno=count;
	}
	public AccountPerson(int accno,double balance ,Person name)
	{
		//parameterised constructor

		
	this.accountno=accno;
		this.accountHolderName=name;
		this.balance=balance;
		
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public Person getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(Person accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
	
		return balance;
		
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public void withdraw(double amount)
	{
			this.balance=balance-amount;
			System.out.println(amount+"amount debited from account");
		
	}
	public void deposit(double amount)
	{
		this.balance=balance+amount;
		System.out.println(amount+"amount credited in account");
	}
    public void printAccountDetails() {
    	System.out.println("accno:"+this.accountno);
    	System.out.println("Account Holder Name:"+this.accountHolderName);
    	System.out.println("Balance:"+this.balance);
    	
	}
    public String toString()
    {
    	return accountno+":"+accountHolderName+":"+balance;
    }
}
