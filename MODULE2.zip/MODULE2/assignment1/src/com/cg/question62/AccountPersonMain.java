package com.cg.question62;

import java.util.Scanner;

import com.cg.exception.AgeException;

public class AccountPersonMain {
public static void main(String[] args) {
	Person p1=new Person("Smith",5);
	
	Person p2=new Person("kathy",33);
	
	

	AccountPerson acc1=new AccountPerson();
	p1.validateAge();
	acc1.setAccountHolderName(p1);
	acc1.setBalance(2000);
	acc1.deposit(2000);

	acc1.printAccountDetails();
	AccountPerson acc2=new AccountPerson();
	acc2.setAccountHolderName(p2);
	acc2.setBalance(3000);
  //  acc2.withdraw(2000);
	acc2.printAccountDetails();
	AccountPerson saving=new SavingAccount();
	saving.withdraw(400);
	saving.setBalance(3000);

	AccountPerson current=new SavingAccount();
	current.withdraw(20000);
	
	

}


}
