package com.cg.question62;

import com.cg.exception.AgeException;

public class Person  {
				
      
			private String name;
			private int age;
			Person()
			{}
			public Person(String name,int age)
			{
				this.name=name;
				this.age=age;
				
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age =  age;
			}
			public void validateAge()
			{try{
				if(age<18)
			   throw new AgeException(age);
			    System.out.println("you are valid for registration");
			}
			catch(AgeException e)
			{e.printError();}
			}
			 public String toString()
			    {
			    	return name+":"+age;
			    }
			
	}		
		

