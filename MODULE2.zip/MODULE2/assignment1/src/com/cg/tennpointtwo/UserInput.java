package com.cg.tennpointtwo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
public class UserInput {
public static void main(String[] args) {
	Connection con=DatabaseConnection.getConnection();
	   String insQuery="insert into employee_masters"
	   		+ "(id,name,salary,designation,insuranceScheme)"
			   +"values(emp_id_seq.nextval,?,?,?,?)";
	try{
		PreparedStatement ps=con.prepareStatement(insQuery);

		ps.setString(1, "renuka");
		ps.setDouble(2, 44000);

		ps.setInt(3,3);
		ps.setString(4,"scheme A");
		int r=ps.executeUpdate();
		String sql="select emp_id_seq.currval from dual";
		Statement stmt=con.createStatement();
		ResultSet rs= stmt.executeQuery(sql);
		int empid=0;
		if(rs.next())
			empid=rs.getInt(1);
		System.out.println("employee record inserted with empid:"+empid);
		
		System.out.println(r+"rows inserted");
	}
	   catch(SQLException e)
	   {
		   e.printStackTrace();
	   }


	
}
}
