package com.cg.tennpointtwo;


import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;

public class Employee<insuranceScheme> implements EmployeeService {
	 int id;
	 String name; 
	 double salary; 
	 String designation; 
	 String insuranceScheme;
	 public Employee(int id,String name,double salary, String designation)
	 {
		this.id=id; 
		this.name=name;
		this.salary=salary;
		this.designation=designation;
	 }
	 public void display()
	 {
		 System.out.println("Name="+this.name);
		 System.out.println("Id="+this.id);
		 System.out.println("salary="+this.salary);
		 System.out.println("Designation="+this.designation);
	 }
	 
			
			
	 
	 public void insuranceScheme(double salary,String Designation)
	   {
		 this.salary=salary;
		 Designation=this.designation;
	   if((salary>5000 && salary<20000) && Designation=="System Associate")
		{
		   this.insuranceScheme="Scheme C";
		   System.out.println("insurance scheme is:"+this.insuranceScheme);
			
		}
		if((salary>=20000 && salary<40000) && Designation=="Programmer")
		{
			this.insuranceScheme="scheme B";
			System.out.println("insurance scheme is:"+this.insuranceScheme);
		}	
		if((salary>=40000) && Designation=="Manager")
		{
			this.insuranceScheme="scheme A";
			System.out.println("insurance scheme is:"+this.insuranceScheme);
		}	
		if((salary<5000) && Designation=="Clerk")
		{
			this.insuranceScheme="No Scheme";
			System.out.println("insurance scheme is:"+this.insuranceScheme);
		}
		else 
			this.insuranceScheme="invalid";
		
	   }
	@Override
	public void checkSalary() {
		// TODO Auto-generated method stub
		
	}
	
	 
}
