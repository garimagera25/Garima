package com.cg.tennpointtwo;

public interface EmployeeService {
  public void insuranceScheme(double salary,String Designation);
  public void display();
  public void checkSalary();
}
