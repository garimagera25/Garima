package com.cg.eis.exception;

public class EmployeeException extends Exception {
	private double salary;
	
	public void salaryException(double sal)
	{
		this.salary=sal;
	}
	public void printError()
	{
		System.out.println("salary is less than 3000");
	}
}

