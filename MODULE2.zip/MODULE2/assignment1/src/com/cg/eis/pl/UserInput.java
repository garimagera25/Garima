package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;


public class UserInput {
public static void main(String[] args) {
	Employee es=new Employee(101,"renuka",500,"Manager");
	es.insuranceScheme(40000,"Manager");
	es.checkSalary();
	es.display();
	
}
}
