package com.cg.lab4;

public class CurrentAccount extends AccountPerson {
 final double overdraftlimit=10000;
 @Override

	public void withdraw(double amount)
	{
		if(amount>overdraftlimit)
		{
			System.out.println("over draft limit reached");
			
		}
		else
		{
			result();
			super.withdraw(amount);
		}
		
	}
 private boolean result()
 {
	 return true;
 }
}
