package com.cg.lab4;

public class SavingAccount extends AccountPerson {
	 final double minbalance=500;
	 @Override

		public void withdraw(double amount)
		{
			if(amount<minbalance)
			{
				System.out.println("less than minimum balance");
				
			}
			else
			{
				
				super.withdraw(amount);
			}
			
		}
	
}
