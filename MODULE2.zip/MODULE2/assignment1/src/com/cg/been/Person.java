package com.cg.been;
public class Person
{
		String Firstname;
		String Lastname;
		char gender;
		String Fullname;

		public String getFullname(String Firstname,String Lastname) {
			this.Fullname=Firstname+Lastname;
			return Fullname;
		}
		public void ValidateFullname(String Fullname)
		{
			System.out.println("Exception");
			try
			{ 
				if(Fullname==null)
				{
					throw new FullNameException(Fullname);
					
					
				}	System.out.println("fields cannot be blank");
			
			}
			catch(FullNameException e)
			{
				e.printError();
			}
		}
		public void setFullname(String Fullname) {
			Fullname = Fullname;
		}
		public String getFirstname() {
			return Firstname;
		}
		public void setFirstname(String firstname) {
			Firstname = firstname;
		}
		public String getLastname() {
			return Lastname;
		}
		public void setLastname(String lastname) {
			Lastname = lastname;
		}
		
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		public Person(String Firstname,String Lastname,char gender)
		{
			this.Firstname=Firstname;
			this.Lastname=Lastname;
			this.gender=gender;
		}
		
		public Person()
		{
			 //default constructor
		}
		void printpersondetails()
		{   //parameterised constructor
			System.out.println("firstname="+Firstname);
			System.out.println("lirstname="+Lastname);
			System.out.println("Gender="+gender);
			
			
		}
		
		
		}

