package com.cg.been;

public class FullNameException extends Exception {
 private String Fullname;
 public FullNameException(String Fullname)
 {
	 this.Fullname=Fullname;
 }
 public void printError()
 {
	 System.out.println("fields cannot be null");
 }
}
