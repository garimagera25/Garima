package com.cg.ten;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class propertydemo {
public static void main(String[] args) {
	try{
		InputStream file=new FileInputStream("./resources/personprops.properties");
	Properties prop=new Properties();
	prop.load(file);
	String Name=prop.getProperty("name");
	String Age=prop.getProperty("age");
	String Weight=prop.getProperty("weight");
	System.out.println("name:"+Name);
	System.out.println("age:"+Age);
	System.out.println("weight:"+Weight);
	}
	catch(FileNotFoundException e)
	{
		System.out.println("file not found");
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
}
}
