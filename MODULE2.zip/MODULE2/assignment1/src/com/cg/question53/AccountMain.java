package com.cg.question53;
import java.util.Scanner;
public class AccountMain {
	
	
	public static void main(String[] args) {
		Person p1=new Person("Smith",44);
		
		Person p2=new Person("kathy",33);
		p1.setBalance(4000);
		p1.setAccountHolderName(p1);
		p1.deposit(2000);
		p1.printAccountDetails();
		p2.setBalance(30000);
		p2.setAccountHolderName(p2);
		p2.withdraw(2000);
		p2.printAccountDetails();
		
		
}
}

