package com.cg.question53;



public abstract class Account {
	int accountno;
	 Person accountHolderName;
	 double balance;
	 int count;
	 
	public int getAccountno() {
		return accountno;
	}
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public Person getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(Person accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void withdraw(double amount)
	{
			this.balance=balance-amount;
			System.out.println(amount+"amount debited from account");
		
	}
	public void deposit(double amount)
	{
		this.balance=balance+amount;
		System.out.println(amount+"amount credited in account");
	}
    public void printAccountDetails() {
    	System.out.println("accno:"+this.accountno);
    	System.out.println("Account Holder Name:"+this.accountHolderName);
    	System.out.println("Balance:"+this.balance);
    	
	}
    public String toString()
    {
    	return accountno+":"+accountHolderName+":"+balance;
    }
}
	

