package assignment1;
class MyThread implements Runnable{
public void run()
{}
}
public class ThreadDemo 
{
public static void main(String []args){
Thread thread = new Thread(new MyThread());
//line 1
thread.start();

}}
