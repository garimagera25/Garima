package assignment1;

public class persondetails {

}
