
public class Product {
	
   private String Pname;
   public Product(String Pname)
   {
	   this.Pname=Pname;
   }
public String getPname() {
	return Pname;
}
public void setPname(String pname) {
	Pname = pname;
}

public String toString() {
	return Pname;
}
}
