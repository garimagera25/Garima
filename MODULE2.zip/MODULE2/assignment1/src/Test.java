import java.util.HashSet;
import java.util.Set;

public int Data {

	Integer data;
	Data(Integer d)
	{
		data=d;
	}
	public boolean equals(Object o)
	{
		return true;
		
	}
	public int hashcode()
	{
		return 1;
	}
}
	public class Test{
		public static void main(String[] args) {
			Set<Data> hash=new HashSet<Data>();
			hash.add(new Data(4));
			hash.add(new Data(2));
			hash.add(new Data(4));
			hash.add(new Data(1));
			hash.add(new Data(2));
		System.out.println(hash.size());
		}
}
