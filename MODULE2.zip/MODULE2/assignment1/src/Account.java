
public class Account {
	private int accountno;
	private String accountHolderName;
	private double balance;
	private static double interestRate;
	static
	{
		//static constructor
		interestRate=6.0;
	}
	private String accountType;
    
	public static void changeInterestRate(double rate)
	{
		interestRate=rate;
	}
	public Account()
    {
		 //default constructor
    }
	public Account(int accno, String name,double balance)
	{
		//parameterised constructor
		accountno=accno;
		accountHolderName=name;
		this.balance=balance;
		System.out.println("in second");
	}
	
	public Account(int accno,String name, double balance,double rate,String type)
	{ 
		this(accno,name,balance);//need to be the first statement when u call another constructor
		this.interestRate= rate;
		this.accountType=type;
		System.out.println("third constructor");
	}
	//getter method
	public int getAccountno() {
		return accountno;
	}
	//setter method
	public void setAccountno(int accountno) {
		this.accountno = accountno;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public void withdraw(double amount)
	{
		if(balance<amount)
		{
			System.out.println("Insufficient balance");
			
		}
		else
		{
			balance=balance-amount;
			System.out.println(amount+"amount debited from account");
		}
		
	}
	public void deposit(double amount)
	{
		balance=balance+amount;
		System.out.println(amount+"amount credited in account");
	}
    public void printAccountDetails() {
    	System.out.println("accno:"+accountno);
    	System.out.println("Account Holder Name:"+accountHolderName);
    	System.out.println("Balance:"+balance);
    	System.out.println("interest rate:"+interestRate);
    	System.out.println("account type:"+accountType);
    	
	}
    public String toString()
    {
    	return accountno+":"+accountHolderName+":"+balance;
    }
}
