
public class StringOperations {
int choice;
StringOperations()
{ 
	}
public int getChoice() {
	return choice;
}
public void setChoice(int choice) {
	this.choice = choice;
}
public void strCat(String str1)
 {
	String str=str1+str1;
	System.out.println("concatenated string is"+str);
	
 }
 public void strOdd(String str1)
 {
	 for(int i=0; i<str1.length();i++)
	 {
		 if(i%2!=0)
		 { 
			 str1=str1.substring(0,i-1)+ "#" +str1.substring(i,str1.length());
		    
		 }
	 }
	 System.out.println("odd index replaced " +str1);
 }
 public void strdup(String str1)
 {
	String temp="";
	String str2="";
	int count=0;
	 for(int i=0; i<str1.length();i++)
	 {
		 temp="";
		 temp+=str1.charAt(i);
		 
		 for(int j=0; i<str1.length();j++)
		 {
			 if(str1.charAt(j)==temp.charAt(0))
			 count++;
		 }
	 }
	
	if(count==1)
	 {
		 str2+=temp;
	 }
	 System.out.println(str2);
 }
 
 public void strupp(String str1)
 {

	 for(int i=0; i<str1.length();i++)
	 {
		 if(i%2!=0)
		 { str1=str1.toUpperCase();
		   System.out.println("coverted odd places to uppercase:"+str1);
		 }
	 }
 }
}