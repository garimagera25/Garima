
public class Demo {
	int num;
	public static void print(int num)//cant accesss non static variable
	{
	num=num;
		
	}
public static void main(String[] args) {
/*	char ch='e';
	float f=ch;
	System.out.println(f);
	int ch=35; 
	boolean b=ch;
	System.out.println(b);
	*/
//	final int num=456;
//	System.out.println(num++);fi
/*	String str1="Hello";
	String str2="Hello";
	if(str1==str2)//referring to same object or not     output is equal
	{
		System.out.println("equal");
		
	}
	else
		System.out.println("not equal");
	
}*/
	String str1="Hello";
	String str2=new String("Hello");
	if(str1==str2)//referring to same object or not.....output is not equal 
	{
		System.out.println("equal");
		
	}
	else
		System.out.println("not equal");
}
}
