import java.util.ArrayList;
import java.util.Arrays;//import java.util.ArrayList;
import java.util.Comparator;
public class ProductNames {
	public static void main(String[] args) {
	
		Product p1= new Product("sugar");
		Product p2= new Product("salt");
		Product p3= new Product("sweet");
		Product p4= new Product("ketchup");
		Product  p5= new Product("idli");
		Product p6= new Product("rava");
		Product arr[]= new Product[6];
		arr[0]= p1;
		arr[1]= p2;
		arr[2]= p3;
		arr[3]= p4;
		arr[4]= p5;
		arr[5]= p6;
		Arrays.sort(arr, new ProductComp());
		for(Product person : arr ){
			System.out.println(person);
		}
		
//import java.util.Arrays;
//import java.util.Comparator;
//public class ProductNames {
//	public static void main(String[] args) 
//	{
//		ArrayList list=new ArrayList();
//		list.add("Idli");
//		list.add("Rava");
//		list.add("Maggi");
//		list.add("sambar");
//		 for(String arr1:list)
//			 
//		    	System.out.println(arr1);
////		String[] arr={"Idli","Rava","Maggi","sambar"};
////
////	      Arrays.sort(arr);
////	    System.out.println("After Sorting");
////	    for(String arr1:arr)
////	    	System.out.println(arr1);
//		
}
}
