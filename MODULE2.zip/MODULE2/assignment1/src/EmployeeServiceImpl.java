
import java.util.HashMap;
import java.util.HashSet;

import com.cg.eis.bean.Employee;
public class EmployeeServiceImpl {
	public static void main(String[] args) {
		
	
	HashMap<String,Employee> list = new HashMap<String,Employee>();
	map.put("ravi");
	map.put("")
	
	}
}
