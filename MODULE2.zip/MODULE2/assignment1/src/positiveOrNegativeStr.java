import java.util.Scanner;
public class positiveOrNegativeStr {
 public static void main(String[] args) {
	 positiveOrNegativeStr obj=new positiveOrNegativeStr();
	 Scanner sc=new Scanner(System.in);
		System.out.println("enter string");
		String positivestring =sc.next();
		
		int isnotpositiveString=0;
		for(int i=0;i<positivestring.length()-1;i++)
		{
			char char1=positivestring.charAt(i);
			int ascii1=(int)char1;
			char char2=positivestring.charAt(i+1);
			int ascii2=(int)char2;
			if(ascii2<ascii1)
			{
				isnotpositiveString=1;
			}
		}
		if(isnotpositiveString==1)
		{
			System.out.println("string is negative");
			
		}
		else
			System.out.println("string is positive");
		sc.close();
}
}
