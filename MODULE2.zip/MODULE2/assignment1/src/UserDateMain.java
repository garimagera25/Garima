import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
public class UserDateMain {
public static void main(String[] args) {
	LocalDate date= LocalDate.now();
	System.out.println("today is"+date);
	Scanner sc=new Scanner(System.in);
	System.out.println("enter date(dd/mm/yyyy)");
	String dt8=sc.next();
	sc.close();
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate dat=LocalDate.parse(dt8,formatter);
	System.out.println(dat);
	Period period=Period.between(dat, date);
	System.out.println(period);
}
}
