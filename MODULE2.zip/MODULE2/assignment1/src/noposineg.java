
public class noposineg {
public static void main(String[] args)
{
	System.out.println(Integer.parseInt(args[0]));
	if(Integer.parseInt(args[0])>0)
	System.out.println("number is positive");
	else
	System.out.println("number is negative");	
}
}


