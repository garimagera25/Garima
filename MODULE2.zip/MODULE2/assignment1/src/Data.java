import java.util.Scanner;

class Data
{
	public static void main(String[] args) {
		String str="a, an ,the should be at appropriate places ";
		Scanner scanner=new Scanner(str);
		scanner.useDelimiter(",");
		while (scanner.hasNext()) {
			System.out.println(scanner.next());
			
		}
		
	}}


