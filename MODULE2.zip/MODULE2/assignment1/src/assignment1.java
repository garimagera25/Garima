
public class assignment1 {
public static void main(String[] args) {
	System.out.println("First Name:"+args[0]);
	System.out.println("Last Name:"+args[1]);
	System.out.println(" Gender:"+args[2]);
	System.out.println("Age:"+args[3]);
	System.out.println("Weight:"+args[4]);
}
}
