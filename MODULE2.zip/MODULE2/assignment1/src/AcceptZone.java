
import java.time.*;

import java.util.*;


public class AcceptZone {
public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
    System.out.println("please enter time zone in the format Brazil/East");
	System.out.println("enter zone");
	String ZoneEntered=sc.next();
	
	ZoneId zone1=ZoneId.of(ZoneEntered);
	LocalTime now1=LocalTime.now(zone1);
	System.out.println(now1);
    sc.close();
	
}
}
