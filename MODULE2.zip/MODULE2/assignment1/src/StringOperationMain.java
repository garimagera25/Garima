import java.util.Scanner;
public class StringOperationMain {
public static void main(String[] args) {
	StringOperations Obj=new StringOperations();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter name");
	String str =sc.next();
	System.out.println("enter your choice");
	int ch=sc.nextInt();
	sc.close();
	System.out.println("string=" +str);
	System.out.println("your choice+" +ch);
	switch(ch)
	{
	case 1: Obj.strCat(str); break;
	case 2: Obj.strOdd(str); break;
	case 3: Obj.strdup(str); break;
	case 4: Obj.strupp(str); break;
	default: System.out.println("wrong choice");
	}
	
	
}
}
