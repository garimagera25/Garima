import java.util.Comparator;


public class ProductComp implements Comparator<Product> {

 @Override
public int compare(Product p1,Product p2)
{ String name1=p1.getPname();
  String name2=p2.getPname();
  return name1.compareTo(name2);
  
	}

}
