import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;


public class Warrantyexpires {
public static void main(String[] args) {

	Scanner sc=new Scanner(System.in);
	System.out.println("enter purchase date(dd/mm/yyyy)");
	String dt8=sc.next();
	sc.close();
	
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate dat=LocalDate.parse(dt8,formatter);
	System.out.println(dat);
	
	Scanner sc1=new Scanner(System.in);
	System.out.println("enter warranty period)");
	
	String period[]=sc1.split("-");
	int years=Integer.parseInt(period[0]);
	int months=Integer.parseInt(period[1]);
	System.out.println(years+""+months);
	LocalDate wd=dat.plusYears(years);
	LocalDate wd1=dat.plusMonths(months);
	sc1.close();
		
}
}
