import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class TwoLocalDates {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter date(dd/MM/yyyy)");
		String dt1=sc.next();
//		sc.close();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dat=LocalDate.parse(dt1,formatter);
		System.out.println(dat);
		
//		Scanner sc=new Scanner(System.in);
		System.out.println("enter date(dd/MM/yyyy)");
		String dt2=sc.next();
//		sc1.close();
		DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate dat1=LocalDate.parse(dt2,formatter1);
		System.out.println(dat1);
		Period period=Period.between(dat, dat1);
		System.out.println(period);
		
		sc.close();
	}
	
}
