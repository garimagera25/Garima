import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class PropertiesDemo {
public static void main(String[] args) {
	try{
	InputStream file=new FileInputStream("./src/DemoOnProperties.properties");
	Properties prop =new Properties();
	prop.load(file);
	String user=prop.getProperty("username");
	String pwd=prop.getProperty("password");
	String empid=prop.getProperty("empid");
	String db=prop.getProperty("database");
	System.out.println("user:"+user);
	System.out.println("password:"+pwd);
	System.out.println("ID:"+empid);
	System.out.println("Database:"+db);
	}
	catch(FileNotFoundException e)
	{
		System.out.println("file not found");
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}

	
}
}
